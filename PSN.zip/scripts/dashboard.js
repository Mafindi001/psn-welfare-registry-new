/**
 * Dashboard Functionality for PSN Welfare Registry
 */

// Dashboard State
let currentSection = 'dashboard';
let specialDates = [];
let nextOfKin = [];
let userData = {};

// DOM Elements
const sidebar = document.getElementById('sidebar');
const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const logoutBtn = document.getElementById('logoutBtn');
const navItems = document.querySelectorAll('.nav-item');
const pageTitle = document.getElementById('pageTitle');
const pageSubtitle = document.getElementById('pageSubtitle');

// Section elements
const dashboardSection = document.getElementById('dashboardSection');
const profileSection = document.getElementById('profileSection');
const specialDatesSection = document.getElementById('specialDatesSection');
const nextOfKinSection = document.getElementById('nextOfKinSection');
const remindersSection = document.getElementById('remindersSection');
const settingsSection = document.getElementById('settingsSection');

// Modal elements
const addDateModal = document.getElementById('addDateModal');
const addKinModal = document.getElementById('addKinModal');
const addDateBtn = document.getElementById('addDateBtn');
const addNextKinBtn = document.getElementById('addNextKinBtn');
const cancelDateBtn = document.getElementById('cancelDateBtn');
const cancelKinBtn = document.getElementById('cancelKinBtn');
const saveDateBtn = document.getElementById('saveDateBtn');
const saveKinBtn = document.getElementById('saveKinBtn');
const modalCloses = document.querySelectorAll('.modal-close');

// Other buttons
const editProfileBtn = document.getElementById('editProfileBtn');
const changePasswordBtn = document.getElementById('changePasswordBtn');
const addNewDateBtn = document.getElementById('addNewDateBtn');
const addFirstDateBtn = document.getElementById('addFirstDateBtn');
const addKinBtn = document.getElementById('addKinBtn');
const viewAllEvents = document.getElementById('viewAllEvents');

/**
 * Initialize Dashboard
 */
function initDashboard() {
    // Check authentication
    if (!requireAuth()) {
        return;
    }

    // Load user data
    loadUserData();

    // Load initial data
    loadSpecialDates();
    loadNextOfKin();

    // Set up event listeners
    setupEventListeners();

    // Show dashboard by default
    showSection('dashboard');

    // Update stats
    updateStats();
}

/**
 * Load user data from localStorage or API
 */
function loadUserData() {
    const user = getCurrentUser();

    if (!user) {
        // Redirect to login if no user data
        window.location.href = '/pages/login.html';
        return;
    }

    userData = user;

    // Update UI with user data
    document.getElementById('userName').textContent = user.fullName || 'Pharmacist';
    document.getElementById('userPsn').textContent = user.psnNumber || 'PSN Member';
    document.getElementById('profileName').textContent = user.fullName || 'Not set';
    document.getElementById('profilePsn').textContent = user.psnNumber || 'Not set';
    document.getElementById('profileEmail').textContent = user.email || 'Not set';
    document.getElementById('profilePhone').textContent = user.phone || 'Not set';
    document.getElementById('profileDob').textContent = user.dateOfBirth ?
        formatDate(user.dateOfBirth) : 'Not set';
    document.getElementById('profileWedding').textContent = user.weddingDate ?
        formatDate(user.weddingDate) : 'Not set';

    // Set profile completion percentage
    calculateProfileCompletion();
}

/**
 * Calculate and update profile completion
 */
function calculateProfileCompletion() {
    let completion = 20; // Base score for registration
    const fields = [
        userData.fullName,
        userData.phone,
        userData.dateOfBirth,
        userData.weddingDate
    ];

    // Add points for each filled field
    fields.forEach(field => {
        if (field) completion += 20;
    });

    // Cap at 100%
    completion = Math.min(completion, 100);

    document.getElementById('profileComplete').textContent = `${completion}%`;
}

/**
 * Load special dates (mock data for now)
 */
function loadSpecialDates() {
    // Mock data - replace with API call
    specialDates = [
        {
            id: '1',
            label: 'Birthday',
            date: '1985-05-15',
            isAnnual: true,
            reminderEnabled: true,
            recipients: ['member', 'primary_kin']
        },
        {
            id: '2',
            label: 'Wedding Anniversary',
            date: '2015-06-22',
            isAnnual: true,
            reminderEnabled: true,
            recipients: ['member', 'primary_kin']
        },
        {
            id: '3',
            label: 'Child\'s Birthday',
            date: '2018-03-10',
            isAnnual: true,
            reminderEnabled: true,
            recipients: ['member']
        }
    ];

    updateSpecialDatesUI();
}

/**
 * Load next of kin (mock data for now)
 */
function loadNextOfKin() {
    // Mock data - replace with API call
    nextOfKin = [
        {
            id: '1',
            fullName: 'Jane Pharmacist',
            relationship: 'Spouse',
            phone: '0803 987 6543',
            email: 'jane@example.com',
            isPrimary: true
        },
        {
            id: '2',
            fullName: 'Dr. James Parent',
            relationship: 'Parent',
            phone: '0802 123 4567',
            email: 'james@example.com',
            isPrimary: false
        }
    ];

    updateNextOfKinUI();
}

/**
 * Update special dates in UI
 */
function updateSpecialDatesUI() {
    const datesTableBody = document.getElementById('datesTableBody');
    const noDatesMessage = document.getElementById('noDatesMessage');
    const datesTable = document.getElementById('datesTable');

    if (specialDates.length === 0) {
        noDatesMessage.style.display = 'block';
        datesTable.style.display = 'none';
        return;
    }

    noDatesMessage.style.display = 'none';
    datesTable.style.display = 'table';

    // Clear existing rows
    datesTableBody.innerHTML = '';

    // Add rows for each date
    specialDates.forEach(date => {
        const row = document.createElement('tr');

        // Calculate days until
        const today = new Date();
        const eventDate = new Date(date.date);
        eventDate.setFullYear(today.getFullYear()); // Use current year for comparison

        const daysUntil = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24));

        row.innerHTML = `
            <td class="date-label">${date.label}</td>
            <td class="date-value">${formatDate(date.date)}</td>
            <td>${date.isAnnual ? '<i class="fas fa-check" style="color: var(--secondary-color);"></i>' : '<i class="fas fa-times" style="color: var(--text-light);"></i>'}</td>
            <td>${getRecipientsText(date.recipients)}</td>
            <td><span class="date-status ${date.reminderEnabled ? 'status-active' : 'status-inactive'}">${date.reminderEnabled ? 'Active' : 'Inactive'}</span></td>
            <td>
                <button class="btn btn-outline btn-sm" onclick="editDate('${date.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-outline btn-sm" onclick="deleteDate('${date.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;

        datesTableBody.appendChild(row);
    });
}

/**
 * Update next of kin in UI
 */
function updateNextOfKinUI() {
    const nextkinGrid = document.getElementById('nextkinGrid');

    // Clear existing cards
    nextkinGrid.innerHTML = '';

    if (nextOfKin.length === 0) {
        nextkinGrid.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-users"></i>
                <h3>No next of kin added</h3>
                <p>Add your emergency contacts for welfare purposes</p>
                <button class="btn btn-primary" onclick="openAddKinModal()">
                    <i class="fas fa-user-plus"></i> Add First Contact
                </button>
            </div>
        `;
        return;
    }

    // Add cards for each next of kin
    nextOfKin.forEach(kin => {
        const card = document.createElement('div');
        card.className = 'nextkin-card';

        card.innerHTML = `
            ${kin.isPrimary ? '<span class="primary-badge">Primary</span>' : ''}
            <div class="nextkin-header">
                <h3 class="nextkin-name">${kin.fullName}</h3>
                <span class="nextkin-relationship">${kin.relationship}</span>
            </div>
            <div class="nextkin-details">
                <div class="nextkin-detail">
                    <i class="fas fa-phone"></i>
                    <span>${kin.phone}</span>
                </div>
                ${kin.email ? `
                <div class="nextkin-detail">
                    <i class="fas fa-envelope"></i>
                    <span>${kin.email}</span>
                </div>
                ` : ''}
            </div>
            <div class="event-actions">
                <button class="btn btn-outline btn-sm" onclick="editKin('${kin.id}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-outline btn-sm" onclick="deleteKin('${kin.id}')">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        `;

        nextkinGrid.appendChild(card);
    });
}

/**
 * Update dashboard stats
 */
function updateStats() {
    // Count birthdays and anniversaries
    const birthdays = specialDates.filter(d =>
        d.label.toLowerCase().includes('birthday')).length;
    const anniversaries = specialDates.filter(d =>
        d.label.toLowerCase().includes('anniversary')).length;

    // Count upcoming events (within next 60 days)
    const today = new Date();
    const upcoming = specialDates.filter(date => {
        const eventDate = new Date(date.date);
        eventDate.setFullYear(today.getFullYear());
        const daysUntil = (eventDate - today) / (1000 * 60 * 60 * 24);
        return daysUntil >= 0 && daysUntil <= 60;
    }).length;

    document.getElementById('birthdayCount').textContent = birthdays;
    document.getElementById('anniversaryCount').textContent = anniversaries;
    document.getElementById('upcomingCount').textContent = upcoming;
}

/**
 * Show a specific section
 */
function showSection(section) {
    // Hide all sections
    const sections = [
        dashboardSection,
        profileSection,
        specialDatesSection,
        nextOfKinSection,
        remindersSection,
        settingsSection
    ];

    sections.forEach(sec => {
        if (sec) sec.style.display = 'none';
    });

    // Update navigation
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('data-section') === section) {
            item.classList.add('active');
        }
    });

    // Show selected section
    currentSection = section;

    switch (section) {
        case 'dashboard':
            pageTitle.textContent = 'Dashboard Overview';
            pageSubtitle.textContent = 'Welcome to your welfare management dashboard';
            dashboardSection.style.display = 'block';
            break;
        case 'profile':
            pageTitle.textContent = 'My Profile';
            pageSubtitle.textContent = 'Manage your personal information';
            profileSection.style.display = 'block';
            break;
        case 'special-dates':
            pageTitle.textContent = 'Special Dates';
            pageSubtitle.textContent = 'Manage your important dates and reminders';
            specialDatesSection.style.display = 'block';
            break;
        case 'next-of-kin':
            pageTitle.textContent = 'Next of Kin';
            pageSubtitle.textContent = 'Manage your emergency contacts';
            nextOfKinSection.style.display = 'block';
            break;
        case 'reminders':
            pageTitle.textContent = 'Reminders';
            pageSubtitle.textContent = 'Configure your notification settings';
            remindersSection.style.display = 'block';
            break;
        case 'settings':
            pageTitle.textContent = 'Settings';
            pageSubtitle.textContent = 'Manage your account preferences';
            settingsSection.style.display = 'block';
            break;
    }
}

/**
 * Open add date modal
 */
function openAddDateModal() {
    addDateModal.style.display = 'flex';
    // Set default date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    document.getElementById('eventDate').value = tomorrow.toISOString().split('T')[0];
}

/**
 * Open add next of kin modal
 */
function openAddKinModal() {
    addKinModal.style.display = 'flex';
    document.getElementById('addKinForm').reset();
}

/**
 * Save new special date
 */
function saveNewDate() {
    const label = document.getElementById('dateLabel').value;
    const date = document.getElementById('eventDate').value;
    const isAnnual = document.getElementById('isAnnual').checked;
    const remindMember = document.getElementById('remindMember').checked;
    const remindNextKin = document.getElementById('remindNextKin').checked;

    if (!label || !date) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }

    // Prepare recipients array
    const recipients = [];
    if (remindMember) recipients.push('member');
    if (remindNextKin) recipients.push('primary_kin');

    // Create new date object
    const newDate = {
        id: Date.now().toString(),
        label,
        date,
        isAnnual,
        reminderEnabled: true,
        recipients
    };

    // Add to array
    specialDates.push(newDate);

    // Update UI
    updateSpecialDatesUI();
    updateStats();

    // Close modal
    addDateModal.style.display = 'none';
    document.getElementById('addDateForm').reset();

    showNotification('Special date added successfully', 'success');
}

/**
 * Save new next of kin
 */
function saveNewKin() {
    const name = document.getElementById('kinName').value;
    const relationship = document.getElementById('kinRelationship').value;
    const phone = document.getElementById('kinPhone').value;
    const email = document.getElementById('kinEmail').value;
    const isPrimary = document.getElementById('isPrimaryKin').checked;

    if (!name || !relationship || !phone) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }

    // If setting as primary, remove primary from others
    if (isPrimary) {
        nextOfKin.forEach(kin => kin.isPrimary = false);
    }

    // Create new kin object
    const newKin = {
        id: Date.now().toString(),
        fullName: name,
        relationship,
        phone,
        email: email || '',
        isPrimary
    };

    // Add to array
    nextOfKin.push(newKin);

    // Update UI
    updateNextOfKinUI();

    // Close modal
    addKinModal.style.display = 'none';
    document.getElementById('addKinForm').reset();

    showNotification('Next of kin added successfully', 'success');
}

/**
 * Edit a special date
 */
function editDate(dateId) {
    const date = specialDates.find(d => d.id === dateId);
    if (!date) return;

    // For now, just alert - implement proper edit modal later
    alert(`Edit date: ${date.label}\nThis feature will be implemented in the next version.`);
}

/**
 * Delete a special date
 */
function deleteDate(dateId) {
    if (!confirm('Are you sure you want to delete this special date?')) {
        return;
    }

    specialDates = specialDates.filter(d => d.id !== dateId);
    updateSpecialDatesUI();
    updateStats();
    showNotification('Special date deleted', 'success');
}

/**
 * Edit next of kin
 */
function editKin(kinId) {
    const kin = nextOfKin.find(k => k.id === kinId);
    if (!kin) return;

    // For now, just alert - implement proper edit modal later
    alert(`Edit contact: ${kin.fullName}\nThis feature will be implemented in the next version.`);
}

/**
 * Delete next of kin
 */
function deleteKin(kinId) {
    if (!confirm('Are you sure you want to remove this next of kin?')) {
        return;
    }

    nextOfKin = nextOfKin.filter(k => k.id !== kinId);
    updateNextOfKinUI();
    showNotification('Next of kin removed', 'success');
}

/**
 * Get text representation of recipients
 */
function getRecipientsText(recipients) {
    if (!recipients || recipients.length === 0) {
        return 'None';
    }

    const texts = recipients.map(r => {
        switch (r) {
            case 'member': return 'You';
            case 'primary_kin': return 'Primary Kin';
            default: return r;
        }
    });

    return texts.join(', ');
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Mobile menu toggle
    mobileMenuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
    });

    // Navigation items
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            showSection(section);

            // Close mobile menu on selection
            if (window.innerWidth <= 992) {
                sidebar.classList.remove('open');
            }
        });
    });

    // Logout
    logoutBtn.addEventListener('click', logout);

    // Modal buttons
    addDateBtn.addEventListener('click', openAddDateModal);
    addNextKinBtn.addEventListener('click', openAddKinModal);
    addNewDateBtn.addEventListener('click', openAddDateModal);
    addFirstDateBtn.addEventListener('click', openAddDateModal);
    addKinBtn.addEventListener('click', openAddKinModal);

    // Save buttons
    saveDateBtn.addEventListener('click', saveNewDate);
    saveKinBtn.addEventListener('click', saveNewKin);

    // Cancel buttons
    cancelDateBtn.addEventListener('click', () => {
        addDateModal.style.display = 'none';
    });

    cancelKinBtn.addEventListener('click', () => {
        addKinModal.style.display = 'none';
    });

    // Modal close buttons
    modalCloses.forEach(btn => {
        btn.addEventListener('click', () => {
            addDateModal.style.display = 'none';
            addKinModal.style.display = 'none';
        });
    });

    // Close modals when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === addDateModal) {
            addDateModal.style.display = 'none';
        }
        if (e.target === addKinModal) {
            addKinModal.style.display = 'none';
        }
    });

    // Other buttons
    editProfileBtn.addEventListener('click', () => {
        alert('Edit profile feature will be implemented in the next version.');
    });

    changePasswordBtn.addEventListener('click', () => {
        alert('Change password feature will be implemented in the next version.');
    });

    viewAllEvents.addEventListener('click', () => {
        showSection('special-dates');
    });
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', initDashboard);
