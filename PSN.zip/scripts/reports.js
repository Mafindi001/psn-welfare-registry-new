/**
 * Advanced Reports Module for PSN Welfare Registry
 */

class ReportGenerator {
    constructor() {
        this.currentReport = null;
        this.reportData = null;
    }

    // Generate different types of reports
    async generateReport(type, params = {}) {
        try {
            showNotification(`Generating ${type} report...`, 'info');

            const response = await ApiService.generateReport(type, params);

            this.currentReport = {
                id: response.reportId,
                type,
                generatedAt: new Date().toISOString(),
                params
            };

            this.reportData = response.data;

            this.displayReportPreview();
            showNotification(`${type} report generated successfully`, 'success');

            return response;
        } catch (error) {
            console.error('Report generation error:', error);
            showNotification(`Failed to generate report: ${error.message}`, 'error');
            throw error;
        }
    }

    // Display report in preview area
    displayReportPreview() {
        const preview = document.getElementById('reportPreview');
        const content = document.getElementById('reportContent');

        if (!preview || !content) return;

        preview.style.display = 'block';

        switch (this.currentReport.type) {
            case 'demographics':
                content.innerHTML = this.generateDemographicsReport();
                break;
            case 'calendar':
                content.innerHTML = this.generateCalendarReport();
                break;
            case 'reminders':
                content.innerHTML = this.generateRemindersReport();
                break;
            case 'growth':
                content.innerHTML = this.generateGrowthReport();
                break;
            case 'comprehensive':
                content.innerHTML = this.generateComprehensiveReport();
                break;
            default:
                content.innerHTML = this.generateDefaultReport();
        }

        // Scroll to preview
        preview.scrollIntoView({ behavior: 'smooth' });
    }

    // Generate demographics report HTML
    // In generateDemographicsReport function, add charts
    generateDemographicsReport() {
        if (!this.reportData) return '<p>No data available</p>';

        const { stats, charts } = this.reportData;

        return `
        <div class="report-section">
            <h4>Member Demographics Report</h4>
            <p>Generated: ${new Date().toLocaleDateString()}</p>
            
            <div class="report-stats-grid">
                <!-- Existing stats... -->
            </div>
            
            <div class="multi-chart-grid">
                <div class="chart-container">
                    <h5>Age Distribution</h5>
                    <canvas id="ageChart"></canvas>
                </div>
                
                <div class="chart-container">
                    <h5>Gender Distribution</h5>
                    <canvas id="genderChart"></canvas>
                </div>
                
                <div class="chart-container">
                    <h5>Membership Growth</h5>
                    <canvas id="growthChart"></canvas>
                </div>
                
                <div class="chart-container">
                    <h5>Activity Distribution</h5>
                    <canvas id="activityChart"></canvas>
                </div>
            </div>
            
            <script>
                // Initialize charts when DOM is loaded
                document.addEventListener('DOMContentLoaded', function() {
                    if (typeof chartManager !== 'undefined') {
                        // Age distribution chart
                        chartManager.createAgeDistributionChart('ageChart', {
                            labels: ['18-25', '26-35', '36-45', '46-55', '56-65', '65+'],
                            values: [15, 42, 68, 45, 22, 8]
                        });
                        
                        // Gender distribution chart
                        chartManager.createDemographicsChart('genderChart', {
                            labels: ['Male', 'Female', 'Prefer not to say'],
                            values: [120, 85, 15]
                        });
                        
                        // Growth chart
                        chartManager.createMemberGrowthChart('growthChart', {
                            labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                            newMembers: [45, 52, 48, 65],
                            totalMembers: [150, 202, 250, 315]
                        });
                        
                        // Activity chart
                        chartManager.createActivityChart('activityChart', {
                            labels: ['Logins', 'Updates', 'Additions', 'Reminders'],
                            thisWeek: [65, 42, 38, 29],
                            lastWeek: [58, 35, 32, 25]
                        });
                    }
                });
            </script>
            
            <div class="report-insights">
                <h5>Key Insights</h5>
                <ul>
                    <!-- Existing insights... -->
                </ul>
            </div>
        </div>
    `;
    }

    // Generate calendar report HTML
    generateCalendarReport() {
        if (!this.reportData) return '<p>No data available</p>';

        const { months, celebrations } = this.reportData;

        return `
            <div class="report-section">
                <h4>Celebration Calendar Report</h4>
                <p>Period: ${months.start} to ${months.end}</p>
                
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Birthdays</th>
                            <th>Anniversaries</th>
                            <th>Total Celebrations</th>
                            <th>Reminders Scheduled</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${celebrations.map(month => `
                            <tr>
                                <td><strong>${month.name}</strong></td>
                                <td>${month.birthdays}</td>
                                <td>${month.anniversaries}</td>
                                <td>${month.total}</td>
                                <td>${month.reminders}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                
                <div class="report-summary">
                    <h5>Summary</h5>
                    <p>Total celebrations in period: <strong>${celebrations.reduce((sum, m) => sum + m.total, 0)}</strong></p>
                    <p>Peak celebration month: <strong>${celebrations.reduce((max, m) => m.total > max.total ? m : max, celebrations[0]).name}</strong></p>
                    <p>Average celebrations per month: <strong>${Math.round(celebrations.reduce((sum, m) => sum + m.total, 0) / celebrations.length)}</strong></p>
                </div>
            </div>
        `;
    }

    // Download report in various formats
    async downloadReport(format = 'pdf') {
        if (!this.currentReport) {
            showNotification('No report generated yet', 'error');
            return;
        }

        try {
            showNotification(`Downloading ${format.toUpperCase()} report...`, 'info');
            await ApiService.downloadReport(this.currentReport.id, format);
            showNotification('Report downloaded successfully', 'success');

            // Log download in audit trail
            await this.logAuditAction('REPORT_DOWNLOAD', {
                reportId: this.currentReport.id,
                reportType: this.currentReport.type,
                format: format
            });

        } catch (error) {
            console.error('Download error:', error);
            showNotification(`Download failed: ${error.message}`, 'error');
        }
    }

    // Export data in various formats
    async exportData(format = 'excel') {
        try {
            showNotification(`Exporting data as ${format.toUpperCase()}...`, 'info');
            await ApiService.exportData(format);
            showNotification('Data exported successfully', 'success');

            // Log export in audit trail
            await this.logAuditAction('DATA_EXPORT', {
                format: format,
                timestamp: new Date().toISOString()
            });

        } catch (error) {
            console.error('Export error:', error);
            showNotification(`Export failed: ${error.message}`, 'error');
        }
    }

    // Log audit action
    async logAuditAction(action, details = {}) {
        try {
            await fetch(`${API_BASE_URL}/admin/audit-logs`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify({
                    action,
                    details,
                    timestamp: new Date().toISOString(),
                    userId: getCurrentUser()?.id
                })
            });
        } catch (error) {
            console.error('Audit log error:', error);
        }
    }
}

// Initialize report generator
const ReportManager = new ReportGenerator();

// Report styles
const reportStyles = `
    <style>
        .report-section {
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .report-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .report-stat {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
            border-left: 4px solid var(--primary-color);
        }
        
        .report-stat h5 {
            margin: 0 0 10px 0;
            color: var(--text-light);
            font-size: 14px;
        }
        
        .report-stat h3 {
            margin: 0;
            color: var(--primary-color);
            font-size: 28px;
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .report-table th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #dee2e6;
        }
        
        .report-table td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }
        
        .report-table tr:hover {
            background: #f8f9fa;
        }
        
        .report-summary {
            margin-top: 20px;
            padding: 15px;
            background: #e8f4fd;
            border-radius: 6px;
            border-left: 4px solid #3498db;
        }
        
        .chart-placeholder {
            height: 200px;
            background: #f8f9fa;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 10px 0;
            color: var(--text-light);
        }
        
        .report-insights {
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 6px;
        }
        
        .report-insights ul {
            margin: 10px 0 0 0;
            padding-left: 20px;
        }
        
        .report-insights li {
            margin-bottom: 5px;
        }
        
        .format-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
`;

// Add styles to document
document.head.insertAdjacentHTML('beforeend', reportStyles);