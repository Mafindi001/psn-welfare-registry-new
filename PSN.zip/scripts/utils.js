/**
 * Utility Functions for PSN Welfare Registry
 */

// API Base URL - Update this based on your backend deployment
const API_BASE_URL = 'http://localhost:5000/api';

/**
 * Show notification message
 * @param {string} message - Message to display
 * @param {string} type - 'success' or 'error'
 * @param {number} duration - Duration in milliseconds
 */
function showNotification(message, type = 'success', duration = 3000) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add styles if not already present
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 9999;
                animation: slideIn 0.3s ease;
                max-width: 400px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 1rem;
            }
            .notification-success {
                background-color: #d4edda;
                color: #155724;
                border-left: 4px solid #28a745;
            }
            .notification-error {
                background-color: #f8d7da;
                color: #721c24;
                border-left: 4px solid #dc3545;
            }
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.75rem;
            }
            .notification-close {
                background: none;
                border: none;
                cursor: pointer;
                color: inherit;
                opacity: 0.7;
                padding: 0;
                line-height: 1;
            }
            .notification-close:hover {
                opacity: 1;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }

    // Add to document
    document.body.appendChild(notification);

    // Add close functionality
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.remove();
    });

    // Auto-remove after duration
    if (duration > 0) {
        setTimeout(() => {
            if (notification.parentNode) {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }
        }, duration);
    }
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} - True if valid
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validate Nigerian phone number
 * @param {string} phone - Phone number to validate
 * @returns {boolean} - True if valid
 */
function isValidNigerianPhone(phone) {
    const phoneRegex = /^(0|234)(7|8|9)(0|1)\d{8}$/;
    return phoneRegex.test(phone.replace(/\s+/g, ''));
}

/**
 * Format date to display format
 * @param {string|Date} date - Date to format
 * @returns {string} - Formatted date (DD/MM/YYYY)
 */
function formatDate(date) {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}/${month}/${year}`;
}

/**
 * Get days until date
 * @param {string|Date} date - Future date
 * @returns {number} - Days until date
 */
function getDaysUntil(date) {
    const today = new Date();
    const target = new Date(date);
    const diffTime = target - today;
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Debounce function for limiting rapid calls
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} - Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Check if user is authenticated
 * @returns {boolean} - True if user has valid token
 */
function isAuthenticated() {
    const token = localStorage.getItem('psn_welfare_token');
    const user = localStorage.getItem('psn_welfare_user');

    if (!token || !user) {
        console.log('No token or user found in localStorage');
        return false;
    }

    // For mock token, just check if it exists
    // In production, you would validate JWT expiry
    if (token.startsWith('mock_jwt_token_') || token === 'mock-jwt-token') {
        console.log('Mock token found, considering authenticated');
        return true;
    }

    // For real JWT tokens, check expiry
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const isExpired = payload.exp < Date.now() / 1000;
        if (isExpired) {
            console.log('Token expired');
            localStorage.removeItem('psn_welfare_token');
            localStorage.removeItem('psn_welfare_user');
        }
        return !isExpired;
    } catch (error) {
        console.log('Invalid token format:', error);
        return false;
    }
}

/**
 * Get current user from localStorage
 * @returns {Object|null} - User object or null
 */
function getCurrentUser() {
    const userStr = localStorage.getItem('psn_welfare_user');
    console.log('Getting user from localStorage:', userStr);

    if (!userStr) {
        console.log('No user data in localStorage');
        return null;
    }

    try {
        const user = JSON.parse(userStr);
        console.log('Parsed user data:', user);
        return user;
    } catch (error) {
        console.error('Failed to parse user data:', error);
        localStorage.removeItem('psn_welfare_user');
        return null;
    }
}

/**
 * Redirect to login if not authenticated
 * @returns {boolean} - True if authenticated
 */
function requireAuth() {
    const isAuth = isAuthenticated();
    console.log('requireAuth check:', isAuth);

    if (!isAuth) {
        console.log('Not authenticated, redirecting to login');
        // Use timeout to avoid redirect loops during page load
        setTimeout(() => {
            window.location.href = '/pages/login.html';
        }, 100);
        return false;
    }
    return true;
}

/**
 * Logout user and clear storage
 */
function logout() {
    console.log('Logging out user');
    localStorage.removeItem('psn_welfare_token');
    localStorage.removeItem('psn_welfare_user');

    // Clear any mock data
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key.startsWith('mock_') || key.includes('psn')) {
            keysToRemove.push(key);
        }
    }
    keysToRemove.forEach(key => localStorage.removeItem(key));

    // Redirect to login page
    window.location.href = '/pages/login.html';
}

/**
 * Logout user and clear storage
 */
function logout() {
    localStorage.removeItem('psn_welfare_token');
    localStorage.removeItem('psn_welfare_user');
    window.location.href = '../pages/login.html';
}

/**
 * Format PSN number with standard format
 * @param {string} psnNumber - Raw PSN number
 * @returns {string} - Formatted PSN number
 */
function formatPSNNumber(psnNumber) {
    if (!psnNumber) return '';

    // Remove spaces and convert to uppercase
    let formatted = psnNumber.replace(/\s+/g, '').toUpperCase();

    // Add hyphens for readability if not present
    if (!formatted.includes('-')) {
        if (formatted.startsWith('PSN')) {
            formatted = formatted.replace(/^PSN/, 'PSN-');
        }
    }

    return formatted;
}

/**
 * Calculate password strength
 * @param {string} password - Password to check
 * @returns {Object} - {score: number, label: string}
 */
function calculatePasswordStrength(password) {
    let score = 0;

    // Length
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;

    // Complexity
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;

    // Labels based on score
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
    const colors = ['#e74c3c', '#e67e22', '#f1c40f', '#3498db', '#2ecc71', '#27ae60'];

    return {
        score: Math.min(score, 5),
        label: labels[Math.min(score, 5)],
        color: colors[Math.min(score, 5)]
    };
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        showNotification,
        isValidEmail,
        isValidNigerianPhone,
        formatDate,
        getDaysUntil,
        debounce,
        isAuthenticated,
        getCurrentUser,
        requireAuth,
        logout,
        formatPSNNumber,
        calculatePasswordStrength
    };
}