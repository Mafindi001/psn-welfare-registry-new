/**
 * Real-time User Activity Monitoring for PSN Welfare Registry
 */

class ActivityMonitor {
    constructor() {
        this.activeUsers = new Map();
        this.recentActivity = [];
        this.socket = null;
        this.updateInterval = null;
        this.isMonitoring = false;
    }

    // Initialize monitoring
    async initialize() {
        await this.loadActiveUsers();
        await this.loadRecentActivity();
        this.setupWebSocket();
        this.startPolling();
        this.setupDashboardUpdates();
    }

    // Load active users
    async loadActiveUsers() {
        try {
            const response = await fetch(`${API_BASE_URL}/admin/monitoring/active-users`, {
                headers: getAuthHeaders()
            });

            const users = await response.json();
            this.activeUsers = new Map(users.map(user => [user.id, user]));
            this.updateActiveUsersUI();

        } catch (error) {
            console.error('Failed to load active users:', error);
        }
    }

    // Load recent activity
    async loadRecentActivity() {
        try {
            const response = await fetch(`${API_BASE_URL}/admin/monitoring/recent-activity`, {
                headers: getAuthHeaders()
            });

            this.recentActivity = await response.json();
            this.updateActivityFeed();

        } catch (error) {
            console.error('Failed to load recent activity:', error);
        }
    }

    // Setup WebSocket for real-time updates
    setupWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.host}/ws/monitoring`;

        try {
            this.socket = new WebSocket(wsUrl);

            this.socket.onopen = () => {
                console.log('Monitoring WebSocket connected');
                this.isMonitoring = true;

                // Send authentication
                const token = localStorage.getItem('psn_welfare_token');
                this.socket.send(JSON.stringify({
                    type: 'AUTH',
                    token: token
                }));
            };

            this.socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleWebSocketMessage(data);
            };

            this.socket.onclose = () => {
                console.log('Monitoring WebSocket disconnected');
                this.isMonitoring = false;

                // Attempt reconnect after 5 seconds
                setTimeout(() => this.setupWebSocket(), 5000);
            };

            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
            };

        } catch (error) {
            console.error('WebSocket setup error:', error);
        }
    }

    // Handle WebSocket messages
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'USER_LOGIN':
                this.handleUserLogin(data.user);
                break;
            case 'USER_LOGOUT':
                this.handleUserLogout(data.userId);
                break;
            case 'USER_ACTION':
                this.handleUserAction(data.action);
                break;
            case 'SYSTEM_ALERT':
                this.handleSystemAlert(data.alert);
                break;
            case 'STATS_UPDATE':
                this.handleStatsUpdate(data.stats);
                break;
        }
    }

    // Handle user login
    handleUserLogin(user) {
        this.activeUsers.set(user.id, user);
        this.updateActiveUsersUI();

        // Add to activity feed
        this.addActivity({
            type: 'login',
            user: user,
            timestamp: new Date().toISOString(),
            message: `${user.fullName} logged in`
        });
    }

    // Handle user logout
    handleUserLogout(userId) {
        this.activeUsers.delete(userId);
        this.updateActiveUsersUI();
    }

    // Handle user action
    handleUserAction(action) {
        this.addActivity({
            type: 'action',
            user: action.user,
            timestamp: action.timestamp,
            message: `${action.user.fullName} ${action.description}`,
            details: action.details
        });
    }

    // Handle system alert
    handleSystemAlert(alert) {
        this.addActivity({
            type: 'alert',
            timestamp: alert.timestamp,
            message: alert.message,
            severity: alert.severity,
            details: alert.details
        });

        // Show notification for critical alerts
        if (alert.severity === 'critical') {
            this.showAlertNotification(alert);
        }
    }

    // Handle stats update
    handleStatsUpdate(stats) {
        this.updateDashboardStats(stats);
    }

    // Start polling for updates (fallback)
    startPolling() {
        this.updateInterval = setInterval(async () => {
            if (!this.isMonitoring) {
                await this.loadActiveUsers();
                await this.loadRecentActivity();
            }
        }, 30000); // Poll every 30 seconds
    }

    // Setup dashboard auto-updates
    setupDashboardUpdates() {
        // Update dashboard stats every minute
        setInterval(async () => {
            await this.updateDashboardStats();
        }, 60000);

        // Refresh activity feed every 2 minutes
        setInterval(async () => {
            await this.loadRecentActivity();
        }, 120000);
    }

    // Update active users UI
    updateActiveUsersUI() {
        const container = document.getElementById('activeUsersList');
        if (!container) return;

        container.innerHTML = '';

        if (this.activeUsers.size === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-users-slash"></i>
                    <p>No active users</p>
                </div>
            `;
            return;
        }

        Array.from(this.activeUsers.values()).forEach(user => {
            const userElement = document.createElement('div');
            userElement.className = 'active-user';
            userElement.innerHTML = `
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="user-info">
                    <strong>${user.fullName}</strong>
                    <small>${user.psnNumber}</small>
                </div>
                <div class="user-status">
                    <span class="status-indicator active"></span>
                    <small>${this.getSessionDuration(user.lastActivity)}</small>
                </div>
            `;

            container.appendChild(userElement);
        });

        // Update active users count
        const countElement = document.getElementById('activeUsersCount');
        if (countElement) {
            countElement.textContent = this.activeUsers.size;
        }
    }

    // Update activity feed
    updateActivityFeed() {
        const feed = document.getElementById('activityFeed');
        if (!feed) return;

        feed.innerHTML = '';

        this.recentActivity.slice(0, 10).forEach(activity => {
            const activityElement = document.createElement('div');
            activityElement.className = 'activity-item';
            activityElement.innerHTML = `
                <div class="activity-icon ${activity.type}">
                    <i class="fas ${this.getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <p class="activity-text">${activity.message}</p>
                    <p class="activity-time">${this.getRelativeTime(activity.timestamp)}</p>
                </div>
            `;

            feed.appendChild(activityElement);
        });
    }

    // Add new activity
    addActivity(activity) {
        this.recentActivity.unshift(activity);

        // Keep only last 50 activities
        if (this.recentActivity.length > 50) {
            this.recentActivity.pop();
        }

        // Update UI
        this.updateActivityFeed();
    }

    // Update dashboard stats
    async updateDashboardStats(stats = null) {
        if (!stats) {
            try {
                const response = await fetch(`${API_BASE_URL}/admin/stats/realtime`, {
                    headers: getAuthHeaders()
                });
                stats = await response.json();
            } catch (error) {
                console.error('Failed to load stats:', error);
                return;
            }
        }

        // Update all stat cards
        this.updateStatCard('totalMembers', stats.totalMembers);
        this.updateStatCard('activeMembers', stats.activeMembers);
        this.updateStatCard('upcomingCelebrations', stats.upcomingCelebrations);
        this.updateStatCard('remindersSent', stats.remindersSent);
        this.updateStatCard('systemHealth', stats.systemHealth);

        // Update last updated time
        const lastUpdated = document.getElementById('lastUpdated');
        if (lastUpdated) {
            lastUpdated.textContent = new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
            });
        }
    }

    // Update individual stat card
    updateStatCard(elementId, value) {
        const element = document.getElementById(elementId);
        if (element) {
            // Animate value change
            const current = parseInt(element.textContent.replace(/,/g, '')) || 0;
            if (current !== value) {
                this.animateValue(element, current, value, 500);
            }
        }
    }

    // Animate value change
    animateValue(element, start, end, duration) {
        const startTime = performance.now();

        const updateValue = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);

            const currentValue = Math.floor(start + (end - start) * progress);
            element.textContent = currentValue.toLocaleString();

            if (progress < 1) {
                requestAnimationFrame(updateValue);
            }
        };

        requestAnimationFrame(updateValue);
    }

    // Show alert notification
    showAlertNotification(alert) {
        const notification = document.createElement('div');
        notification.className = `alert-notification ${alert.severity}`;
        notification.innerHTML = `
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <strong>System Alert</strong>
                <p>${alert.message}</p>
                <small>${new Date(alert.timestamp).toLocaleTimeString()}</small>
            </div>
            <button class="alert-close">
                <i class="fas fa-times"></i>
            </button>
        `;

        document.body.appendChild(notification);

        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 10000);

        // Close button
        notification.querySelector('.alert-close').addEventListener('click', () => {
            notification.remove();
        });
    }

    // Helper: Get session duration
    getSessionDuration(lastActivity) {
        const now = new Date();
        const last = new Date(lastActivity);
        const diff = now - last;
        const minutes = Math.floor(diff / 60000);

        if (minutes < 1) return 'Just now';
        if (minutes < 60) return `${minutes}m ago`;
        return `${Math.floor(minutes / 60)}h ago`;
    }

    // Helper: Get activity icon
    getActivityIcon(type) {
        const icons = {
            'login': 'fa-sign-in-alt',
            'logout': 'fa-sign-out-alt',
            'action': 'fa-user-edit',
            'alert': 'fa-exclamation-circle',
            'system': 'fa-cog',
            'reminder': 'fa-bell'
        };
        return icons[type] || 'fa-info-circle';
    }

    // Helper: Get relative time
    getRelativeTime(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diff = now - time;

        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (seconds < 60) return 'Just now';
        if (minutes < 60) return `${minutes}m ago`;
        if (hours < 24) return `${hours}h ago`;
        return `${Math.floor(hours / 24)}d ago`;
    }

    // Send heartbeat to keep session alive
    sendHeartbeat() {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify({
                type: 'HEARTBEAT',
                timestamp: new Date().toISOString()
            }));
        }
    }

    // Cleanup
    cleanup() {
        if (this.socket) {
            this.socket.close();
        }

        if (this.updateInterval) {
            clearInterval(this.updateInterval);
        }

        this.isMonitoring = false;
    }
}

// Initialize activity monitor
const ActivityTracker = new ActivityMonitor();

// Auto-initialize on admin pages
if (window.location.pathname.includes('admin.html')) {
    document.addEventListener('DOMContentLoaded', () => {
        ActivityTracker.initialize();
    });

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        ActivityTracker.cleanup();
    });
}

// Add monitoring styles
const monitoringStyles = `
    <style>
        .active-user {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .active-user:last-child {
            border-bottom: none;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--bg-light);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-info strong {
            display: block;
            font-size: 0.95rem;
        }
        
        .user-info small {
            color: var(--text-light);
            font-size: 0.85rem;
        }
        
        .user-status {
            text-align: right;
        }
        
        .status-indicator {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            margin-right: 5px;
        }
        
        .status-indicator.active {
            background-color: var(--secondary-color);
            box-shadow: 0 0 0 2px rgba(52, 168, 83, 0.2);
        }
        
        .status-indicator.inactive {
            background-color: var(--text-light);
        }
        
        .activity-item .activity-icon.login {
            background: rgba(52, 168, 83, 0.1);
            color: var(--secondary-color);
        }
        
        .activity-item .activity-icon.alert {
            background: rgba(231, 76, 60, 0.1);
            color: #e74c3c;
        }
        
        .activity-item .activity-icon.system {
            background: rgba(52, 152, 219, 0.1);
            color: #3498db;
        }
        
        .alert-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            padding: 15px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            max-width: 400px;
            z-index: 9999;
            animation: slideIn 0.3s ease;
        }
        
        .alert-notification.critical {
            border-left: 4px solid #e74c3c;
        }
        
        .alert-notification.warning {
            border-left: 4px solid #f39c12;
        }
        
        .alert-notification.info {
            border-left: 4px solid #3498db;
        }
        
        .alert-icon {
            font-size: 1.2rem;
            margin-top: 2px;
        }
        
        .alert-content {
            flex: 1;
        }
        
        .alert-content strong {
            display: block;
            margin-bottom: 5px;
            color: var(--text-color);
        }
        
        .alert-content p {
            margin: 0 0 5px 0;
            font-size: 0.95rem;
        }
        
        .alert-content small {
            color: var(--text-light);
            font-size: 0.85rem;
        }
        
        .alert-close {
            background: none;
            border: none;
            color: var(--text-light);
            cursor: pointer;
            padding: 0;
            font-size: 1rem;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .backup-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .backup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .backup-header h4 {
            margin: 0;
            font-size: 1rem;
        }
        
        .backup-size {
            background: var(--bg-light);
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.85rem;
            color: var(--text-light);
        }
        
        .backup-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .detail-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }
        
        .detail-item i {
            width: 16px;
            color: var(--text-light);
        }
        
        .backup-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
    </style>
`;

// Add styles to document
document.head.insertAdjacentHTML('beforeend', monitoringStyles);