/**
 * Audit Trail System for PSN Welfare Registry
 */

class AuditTrail {
    constructor() {
        this.logs = [];
        this.isMonitoring = false;
        this.updateInterval = null;
    }

    // Initialize audit trail
    async initialize() {
        await this.loadAuditLogs();
        this.startRealtimeMonitoring();
        this.setupPageTracking();
    }

    // Load audit logs
    async loadAuditLogs(filters = {}) {
        try {
            const response = await ApiService.getSystemLogs(1, 100, filters);
            this.logs = response.data;
            this.renderAuditLogs();
            return this.logs;
        } catch (error) {
            console.error('Failed to load audit logs:', error);
            showNotification('Failed to load audit logs', 'error');
            return [];
        }
    }

    // Render audit logs to table
    renderAuditLogs() {
        const tableBody = document.getElementById('logsTableBody');
        if (!tableBody) return;

        tableBody.innerHTML = '';

        this.logs.forEach(log => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>
                    <div class="timestamp">${this.formatTimestamp(log.timestamp)}</div>
                    <small class="text-muted">${this.getRelativeTime(log.timestamp)}</small>
                </td>
                <td>
                    <div class="user-info">
                        <strong>${log.userName || 'System'}</strong>
                        ${log.userRole ? `<br><small>${log.userRole}</small>` : ''}
                    </div>
                </td>
                <td>
                    <span class="action-badge ${this.getActionClass(log.action)}">
                        ${this.formatAction(log.action)}
                    </span>
                </td>
                <td>
                    <div class="log-details">
                        ${this.formatDetails(log.details)}
                        ${log.entityId ? `<br><small>ID: ${log.entityId}</small>` : ''}
                    </div>
                </td>
                <td>
                    <div class="ip-address">${log.ipAddress || 'N/A'}</div>
                    ${log.userAgent ? `<small class="text-muted">${log.userAgent.substring(0, 30)}...</small>` : ''}
                </td>
            `;

            tableBody.appendChild(row);
        });
    }

    // Log an action
    async logAction(action, details = {}) {
        try {
            const user = getCurrentUser();
            const logEntry = {
                action,
                details,
                userId: user?.id,
                userName: user?.fullName,
                userRole: user?.isAdmin ? 'Admin' : 'Member',
                timestamp: new Date().toISOString(),
                ipAddress: await this.getIPAddress(),
                userAgent: navigator.userAgent
            };

            // Send to server
            await fetch(`${API_BASE_URL}/audit-logs`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify(logEntry)
            });

            // Add to local logs
            this.logs.unshift(logEntry);
            if (this.logs.length > 1000) this.logs.pop(); // Keep only 1000 logs

            // Update UI if on logs page
            if (document.getElementById('logsTableBody')) {
                this.renderAuditLogs();
            }

        } catch (error) {
            console.error('Failed to log action:', error);
        }
    }

    // Start real-time monitoring
    startRealtimeMonitoring() {
        if (this.isMonitoring) return;

        this.isMonitoring = true;

        // WebSocket connection for real-time updates
        this.setupWebSocket();

        // Fallback polling
        this.updateInterval = setInterval(async () => {
            await this.checkForNewLogs();
        }, 10000); // Check every 10 seconds
    }

    // Setup WebSocket connection
    setupWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.host}/ws/audit-logs`;

        try {
            this.ws = new WebSocket(wsUrl);

            this.ws.onopen = () => {
                console.log('Audit trail WebSocket connected');
            };

            this.ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.type === 'NEW_LOG') {
                    this.handleNewLog(data.log);
                }
            };

            this.ws.onclose = () => {
                console.log('Audit trail WebSocket disconnected');
                // Attempt reconnect after 5 seconds
                setTimeout(() => this.setupWebSocket(), 5000);
            };

        } catch (error) {
            console.error('WebSocket error:', error);
        }
    }

    // Handle new log from WebSocket
    handleNewLog(log) {
        this.logs.unshift(log);

        // Show notification for important actions
        if (this.isImportantAction(log.action)) {
            this.showLogNotification(log);
        }

        // Update UI
        if (document.getElementById('logsTableBody')) {
            this.renderAuditLogs();
        }
    }

    // Check for new logs via polling
    async checkForNewLogs() {
        try {
            const response = await fetch(`${API_BASE_URL}/admin/audit-logs/recent`, {
                headers: getAuthHeaders()
            });

            const newLogs = await response.json();

            newLogs.forEach(log => {
                if (!this.logs.some(existing => existing.id === log.id)) {
                    this.handleNewLog(log);
                }
            });

        } catch (error) {
            console.error('Polling error:', error);
        }
    }

    // Setup page tracking
    setupPageTracking() {
        // Track page views
        window.addEventListener('load', () => {
            this.logAction('PAGE_VIEW', {
                page: window.location.pathname,
                referrer: document.referrer
            });
        });

        // Track form submissions
        document.addEventListener('submit', (e) => {
            const form = e.target;
            if (form.id) {
                this.logAction('FORM_SUBMIT', {
                    formId: form.id,
                    action: form.action
                });
            }
        });

        // Track important button clicks
        document.addEventListener('click', (e) => {
            const button = e.target.closest('button');
            if (button && button.dataset.auditAction) {
                this.logAction(button.dataset.auditAction, {
                    buttonText: button.textContent,
                    buttonId: button.id
                });
            }
        });
    }

    // Export audit logs
    async exportAuditLogs(format = 'csv', filters = {}) {
        try {
            showNotification('Exporting audit logs...', 'info');

            const logs = await this.loadAuditLogs(filters);
            let content, filename;

            switch (format) {
                case 'csv':
                    content = this.logsToCSV(logs);
                    filename = `audit_logs_${new Date().toISOString().split('T')[0]}.csv`;
                    break;
                case 'json':
                    content = JSON.stringify(logs, null, 2);
                    filename = `audit_logs_${new Date().toISOString().split('T')[0]}.json`;
                    break;
                default:
                    throw new Error('Unsupported format');
            }

            this.downloadFile(content, filename, format);
            showNotification('Audit logs exported successfully', 'success');

        } catch (error) {
            console.error('Export error:', error);
            showNotification(`Export failed: ${error.message}`, 'error');
        }
    }

    // Helper methods
    logsToCSV(logs) {
        const headers = ['Timestamp', 'User', 'Action', 'Details', 'IP Address', 'User Agent'];
        const rows = logs.map(log => [
            `"${this.formatTimestamp(log.timestamp)}"`,
            `"${log.userName || 'System'}"`,
            `"${log.action}"`,
            `"${JSON.stringify(log.details).replace(/"/g, '""')}"`,
            `"${log.ipAddress || 'N/A'}"`,
            `"${log.userAgent || ''}"`
        ]);

        return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    }

    formatTimestamp(timestamp) {
        return new Date(timestamp).toLocaleString();
    }

    getRelativeTime(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diff = now - time;

        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);

        if (minutes < 60) return `${minutes}m ago`;
        if (hours < 24) return `${hours}h ago`;
        return `${days}d ago`;
    }

    formatAction(action) {
        return action.replace(/_/g, ' ').toLowerCase()
            .replace(/\b\w/g, l => l.toUpperCase());
    }

    getActionClass(action) {
        const classes = {
            'CREATE': 'badge-success',
            'UPDATE': 'badge-info',
            'DELETE': 'badge-danger',
            'LOGIN': 'badge-primary',
            'LOGOUT': 'badge-secondary',
            'ERROR': 'badge-warning'
        };
        return classes[action] || 'badge-secondary';
    }

    formatDetails(details) {
        if (typeof details === 'string') return details;
        return JSON.stringify(details, null, 2).substring(0, 100) + '...';
    }

    isImportantAction(action) {
        const importantActions = ['DELETE', 'ERROR', 'SECURITY_BREACH', 'ADMIN_ACTION'];
        return importantActions.includes(action);
    }

    showLogNotification(log) {
        const notification = {
            title: this.formatAction(log.action),
            message: `${log.userName || 'System'} - ${this.formatDetails(log.details)}`,
            timestamp: this.getRelativeTime(log.timestamp),
            type: log.action === 'ERROR' ? 'error' : 'info'
        };

        // Show in activity feed
        this.addToActivityFeed(notification);

        // Show toast notification
        showNotification(`${notification.title}: ${notification.message}`, notification.type);
    }

    addToActivityFeed(notification) {
        const feed = document.getElementById('activityFeed');
        if (!feed) return;

        const activityItem = document.createElement('div');
        activityItem.className = 'activity-item';
        activityItem.innerHTML = `
            <div class="activity-icon">
                <i class="fas fa-${notification.type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i>
            </div>
            <div class="activity-content">
                <p class="activity-text">
                    <strong>${notification.title}</strong><br>
                    ${notification.message}
                </p>
                <p class="activity-time">${notification.timestamp}</p>
            </div>
        `;

        feed.insertBefore(activityItem, feed.firstChild);

        // Limit to 10 items
        if (feed.children.length > 10) {
            feed.removeChild(feed.lastChild);
        }
    }

    async getIPAddress() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            return 'Unknown';
        }
    }

    downloadFile(content, filename, type) {
        const blob = new Blob([content], {
            type: type === 'csv' ? 'text/csv' : 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }
}

// Initialize audit trail
const AuditLogger = new AuditTrail();

// Export for use in other modules
window.AuditLogger = AuditLogger;

// Auto-initialize on admin pages
if (window.location.pathname.includes('admin.html')) {
    document.addEventListener('DOMContentLoaded', () => {
        AuditLogger.initialize();
    });
}