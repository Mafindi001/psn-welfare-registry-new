/**
 * Configuration for PSN Welfare Registry
 * This handles path configurations for different environments
 */

const CONFIG = {
    // Base path for assets - change this based on deployment
    BASE_PATH: window.location.hostname === 'localhost' ? '' : '/psn-welfare-frontend',

    // API URL
    API_URL: window.location.hostname === 'localhost'
        ? 'http://localhost:5000/api'
        : 'https://your-backend-url.com/api',

    // App Info
    APP_NAME: 'PSN Taraba Welfare Registry',
    VERSION: '1.0.0'
};

// Function to get full path for assets
function getAssetPath(relativePath) {
    return CONFIG.BASE_PATH ? `${CONFIG.BASE_PATH}/${relativePath}` : `/${relativePath}`;
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CONFIG, getAssetPath };
}