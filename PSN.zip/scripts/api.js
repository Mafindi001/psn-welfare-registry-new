/**
 * API Service for PSN Welfare Registry - Real Backend Integration
 */

const API_BASE_URL = 'http://localhost:5000/api'; // Your Node.js backend

// Common headers for authenticated requests
function getAuthHeaders() {
    const token = localStorage.getItem('psn_welfare_token');
    return {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    };
}

// Handle API responses
async function handleResponse(response) {
    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'API request failed');
    }
    return response.json();
}

const ApiService = {
    // Auth endpoints
    async register(userData) {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        });
        return handleResponse(response);
    },

    async login(credentials) {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(credentials)
        });
        return handleResponse(response);
    },

    async logout() {
        const response = await fetch(`${API_BASE_URL}/auth/logout`, {
            method: 'POST',
            headers: getAuthHeaders()
        });
        localStorage.removeItem('psn_welfare_token');
        localStorage.removeItem('psn_welfare_user');
        return handleResponse(response);
    },

    // Admin endpoints
    async getAdminStats() {
        const response = await fetch(`${API_BASE_URL}/admin/stats`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async getAllMembers(page = 1, limit = 10, filters = {}) {
        const queryParams = new URLSearchParams({
            page,
            limit,
            ...filters
        });

        const response = await fetch(`${API_BASE_URL}/admin/members?${queryParams}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async getMemberDetails(memberId) {
        const response = await fetch(`${API_BASE_URL}/admin/members/${memberId}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async updateMember(memberId, updates) {
        const response = await fetch(`${API_BASE_URL}/admin/members/${memberId}`, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify(updates)
        });
        return handleResponse(response);
    },

    async deleteMembers(memberIds) {
        const response = await fetch(`${API_BASE_URL}/admin/members/bulk`, {
            method: 'DELETE',
            headers: getAuthHeaders(),
            body: JSON.stringify({ memberIds })
        });
        return handleResponse(response);
    },

    async getReminderLogs(filters = {}) {
        const queryParams = new URLSearchParams(filters);
        const response = await fetch(`${API_BASE_URL}/admin/reminder-logs?${queryParams}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async getUpcomingEvents(days = 30) {
        const response = await fetch(`${API_BASE_URL}/admin/upcoming-events?days=${days}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async getSystemLogs(page = 1, limit = 50, filters = {}) {
        const queryParams = new URLSearchParams({
            page,
            limit,
            ...filters
        });

        const response = await fetch(`${API_BASE_URL}/admin/audit-logs?${queryParams}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    // Report endpoints
    async generateReport(reportType, params = {}) {
        const response = await fetch(`${API_BASE_URL}/admin/reports/${reportType}`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(params)
        });
        return handleResponse(response);
    },

    async downloadReport(reportId, format = 'pdf') {
        const response = await fetch(`${API_BASE_URL}/admin/reports/${reportId}/download?format=${format}`, {
            headers: getAuthHeaders()
        });

        if (!response.ok) throw new Error('Download failed');

        // Handle file download
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `report_${reportId}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        return { success: true };
    },

    // Bulk actions
    async sendBulkEmails(emailData) {
        const response = await fetch(`${API_BASE_URL}/admin/bulk/emails`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(emailData)
        });
        return handleResponse(response);
    },

    async sendBulkReminders(reminderData) {
        const response = await fetch(`${API_BASE_URL}/admin/bulk/reminders`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify(reminderData)
        });
        return handleResponse(response);
    },

    // Backup endpoints
    async createBackup() {
        const response = await fetch(`${API_BASE_URL}/admin/backup`, {
            method: 'POST',
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async getBackups() {
        const response = await fetch(`${API_BASE_URL}/admin/backups`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async restoreBackup(backupId) {
        const response = await fetch(`${API_BASE_URL}/admin/backup/${backupId}/restore`, {
            method: 'POST',
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async exportData(format = 'json') {
        const response = await fetch(`${API_BASE_URL}/admin/export?format=${format}`, {
            headers: getAuthHeaders()
        });

        if (!response.ok) throw new Error('Export failed');

        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `psn_welfare_export_${new Date().toISOString().split('T')[0]}.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);

        return { success: true };
    },

    // Settings endpoints
    async getSystemSettings() {
        const response = await fetch(`${API_BASE_URL}/admin/settings`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    },

    async updateSystemSettings(settings) {
        const response = await fetch(`${API_BASE_URL}/admin/settings`, {
            method: 'PUT',
            headers: getAuthHeaders(),
            body: JSON.stringify(settings)
        });
        return handleResponse(response);
    },

    // Real-time monitoring
    async subscribeToUpdates(callback) {
        // This would use WebSockets in production
        // For now, implement polling
        return setInterval(async () => {
            try {
                const updates = await this.getRecentActivity();
                callback(updates);
            } catch (error) {
                console.error('Update polling error:', error);
            }
        }, 30000); // Poll every 30 seconds
    },

    async getRecentActivity(limit = 10) {
        const response = await fetch(`${API_BASE_URL}/admin/activity?limit=${limit}`, {
            headers: getAuthHeaders()
        });
        return handleResponse(response);
    }
};

