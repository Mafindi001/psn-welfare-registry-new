/**
 * Admin Dashboard Functionality for PSN Welfare Registry
 */

// Admin State
let adminData = {
    currentSection: 'admin-dashboard',
    members: [],
    reminderLogs: [],
    upcomingEvents: [],
    systemLogs: [],
    selectedMembers: new Set(),
    currentPage: 1,
    itemsPerPage: 10,
    totalMembers: 0,
    currentMonth: new Date().getMonth(),
    currentYear: new Date().getFullYear()
};

// DOM Elements
const navItems = document.querySelectorAll('.nav-item');
const sections = {
    'admin-dashboard': document.getElementById('admin-dashboard-section'),
    'manage-members': document.getElementById('manage-members-section'),
    'reminder-logs': document.getElementById('reminder-logs-section'),
    'upcoming-events': document.getElementById('upcoming-events-section'),
    'reports': document.getElementById('reports-section'),
    'system-logs': document.getElementById('system-logs-section'),
    'settings': document.getElementById('settings-section')
};

// Initialize Admin Dashboard
function initAdminDashboard() {
    console.log('Initializing admin dashboard...');

    // Check authentication and admin status
    const user = getCurrentUser();

    if (!requireAuth()) {
        return;
    }

    if (!user || !user.isAdmin) {
        console.log('User is not admin, redirecting to dashboard');
        showNotification('Admin access required. Redirecting to member dashboard.', 'error');
        setTimeout(() => {
            window.location.href = '/pages/dashboard.html';
        }, 2000);
        return;
    }

    console.log('Admin user authenticated:', user);

    // Update admin info
    updateAdminInfo(user);

    // Load initial data
    loadDashboardStats();
    loadMembers();
    loadReminderLogs();
    loadUpcomingEvents();
    loadSystemLogs();

    // Set up event listeners
    setupAdminEventListeners();

    // Initialize calendar
    generateCalendar();

    console.log('Admin dashboard initialized');
}

// Update admin info in sidebar
function updateAdminInfo(user) {
    document.getElementById('adminName').textContent = user.fullName || 'Admin User';
    document.getElementById('adminPsn').textContent = user.psnNumber || 'ADMIN';
    document.getElementById('pageTitle').textContent = `Admin Dashboard - Welcome ${user.fullName?.split(' ')[0] || 'Admin'}`;
}

// Load dashboard statistics
function loadDashboardStats() {
    // Mock data - replace with API calls
    const mockStats = {
        totalMembers: 157,
        upcomingCelebrations: 23,
        remindersSent: 1245,
        activeMembers: 149,
        membersThisMonth: 12
    };

    // Update UI
    document.getElementById('totalMembers').textContent = mockStats.totalMembers;
    document.getElementById('upcomingCelebrations').textContent = mockStats.upcomingCelebrations;
    document.getElementById('remindersSent').textContent = mockStats.remindersSent.toLocaleString();
    document.getElementById('activeMembers').textContent = mockStats.activeMembers;

    // Update navigation badges
    document.getElementById('membersCount').textContent = mockStats.totalMembers;
    document.getElementById('remindersCount').textContent = mockStats.remindersSent.toLocaleString();
    document.getElementById('eventsCount').textContent = mockStats.upcomingCelebrations;

    // Update last updated time
    document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Load members data
async function loadMembers() {
    try {
        // Mock data - replace with API call
        const mockMembers = generateMockMembers(50);
        adminData.members = mockMembers;
        adminData.totalMembers = mockMembers.length;

        renderMembersTable();
        updatePagination();

    } catch (error) {
        console.error('Error loading members:', error);
        showNotification('Failed to load members data', 'error');
    }
}

// Generate mock members data
function generateMockMembers(count) {
    const members = [];
    const names = [
        'Dr. John Pharmacist', 'Dr. Sarah Johnson', 'Dr. Michael Adekunle',
        'Dr. Chinyere Okoro', 'Dr. James Williams', 'Dr. Amina Mohammed',
        'Dr. Chukwudi Nwankwo', 'Dr. Fatima Bello', 'Dr. Emmanuel Okafor',
        'Dr. Grace Chukwu', 'Dr. Ibrahim Musa', 'Dr. Blessing Adeyemi'
    ];

    const domains = ['gmail.com', 'yahoo.com', 'psntaraba.org.ng', 'example.com'];

    for (let i = 1; i <= count; i++) {
        const name = names[Math.floor(Math.random() * names.length)];
        const firstName = name.split(' ')[1]?.toLowerCase() || 'user';
        const domain = domains[Math.floor(Math.random() * domains.length)];

        members.push({
            id: `member_${i}`,
            psnNumber: `PSN-TARA-2024-${i.toString().padStart(3, '0')}`,
            fullName: name,
            email: `${firstName}${i}@${domain}`,
            phone: `0803${Math.floor(1000000 + Math.random() * 9000000)}`,
            status: Math.random() > 0.1 ? 'active' : 'inactive',
            isAdmin: i <= 5, // First 5 are admins
            registeredDate: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            lastLogin: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
        });
    }

    return members;
}

// Render members table
function renderMembersTable() {
    const tableBody = document.getElementById('membersTableBody');
    const searchTerm = document.getElementById('memberSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const typeFilter = document.getElementById('memberTypeFilter').value;

    // Filter members
    let filteredMembers = adminData.members.filter(member => {
        const matchesSearch =
            member.fullName.toLowerCase().includes(searchTerm) ||
            member.psnNumber.toLowerCase().includes(searchTerm) ||
            member.email.toLowerCase().includes(searchTerm);

        const matchesStatus = !statusFilter || member.status === statusFilter;
        const matchesType = !typeFilter ||
            (typeFilter === 'admin' ? member.isAdmin : !member.isAdmin);

        return matchesSearch && matchesStatus && matchesType;
    });

    // Calculate pagination
    const startIndex = (adminData.currentPage - 1) * adminData.itemsPerPage;
    const endIndex = startIndex + adminData.itemsPerPage;
    const paginatedMembers = filteredMembers.slice(startIndex, endIndex);

    // Clear table
    tableBody.innerHTML = '';

    if (paginatedMembers.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="9" class="empty-state-cell">
                    <i class="fas fa-users-slash"></i>
                    <p>No members found matching your criteria</p>
                </td>
            </tr>
        `;
        return;
    }

    // Add rows
    paginatedMembers.forEach(member => {
        const isSelected = adminData.selectedMembers.has(member.id);
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>
                <input type="checkbox" class="member-checkbox" 
                       data-id="${member.id}" ${isSelected ? 'checked' : ''}>
            </td>
            <td>
                <strong>${member.psnNumber}</strong>
            </td>
            <td>
                <div class="member-name">${member.fullName}</div>
                ${member.isAdmin ? '<span class="status-badge" style="background: #667eea; color: white; margin-top: 0.25rem;">Admin</span>' : ''}
            </td>
            <td>${member.email}</td>
            <td>${member.phone}</td>
            <td>
                <span class="status-badge ${member.status === 'active' ? 'status-active' : 'status-inactive'}">
                    ${member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                </span>
            </td>
            <td>${member.isAdmin ? 'Admin' : 'Member'}</td>
            <td>${formatDate(member.registeredDate, 'short')}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-outline btn-sm view-member" data-id="${member.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-outline btn-sm edit-member" data-id="${member.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-outline btn-sm ${member.status === 'active' ? 'btn-danger' : ''}" 
                            data-id="${member.id}" data-action="${member.status === 'active' ? 'deactivate' : 'activate'}">
                        <i class="fas fa-${member.status === 'active' ? 'user-slash' : 'user-check'}"></i>
                    </button>
                </div>
            </td>
        `;

        tableBody.appendChild(row);
    });

    // Update selected count
    updateSelectedCount();
}

// Load reminder logs
async function loadReminderLogs() {
    try {
        // Mock data - replace with API call
        adminData.reminderLogs = generateMockReminderLogs(100);

        renderReminderLogs();
        updateReminderStats();

    } catch (error) {
        console.error('Error loading reminder logs:', error);
        showNotification('Failed to load reminder logs', 'error');
    }
}

// Generate mock reminder logs
function generateMockReminderLogs(count) {
    const logs = [];
    const events = ['Birthday', 'Wedding Anniversary', 'Child\'s Birthday', 'Work Anniversary'];
    const statuses = ['sent', 'sent', 'sent', 'sent', 'failed', 'pending']; // More sent than others
    const members = adminData.members.slice(0, 20); // Use first 20 members

    for (let i = 0; i < count; i++) {
        const member = members[Math.floor(Math.random() * members.length)];
        const event = events[Math.floor(Math.random() * events.length)];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const daysAgo = Math.floor(Math.random() * 30);

        logs.push({
            id: `log_${i}`,
            memberId: member.id,
            memberName: member.fullName,
            recipientEmail: member.email,
            eventType: event,
            eventDate: new Date(Date.now() + Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            sentDate: new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString(),
            status: status,
            errorMessage: status === 'failed' ? 'SMTP connection timeout' : null
        });
    }

    // Sort by sent date (newest first)
    return logs.sort((a, b) => new Date(b.sentDate) - new Date(a.sentDate));
}

// Render reminder logs
function renderReminderLogs() {
    const tableBody = document.getElementById('remindersTableBody');

    // Clear table
    tableBody.innerHTML = '';

    // Show only recent 20 logs
    const recentLogs = adminData.reminderLogs.slice(0, 20);

    recentLogs.forEach(log => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${formatDate(log.sentDate, 'full')}</td>
            <td>
                <div>${log.memberName}</div>
                <small class="text-muted">${log.recipientEmail}</small>
            </td>
            <td>${log.eventType}</td>
            <td>${formatDate(log.eventDate, 'short')}</td>
            <td>
                <span class="status-badge ${log.status === 'sent' ? 'status-active' :
                log.status === 'failed' ? 'status-inactive' : 'status-pending'
            }">
                    ${log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                </span>
            </td>
            <td>Email</td>
            <td>
                <button class="btn btn-outline btn-sm view-log" data-id="${log.id}">
                    <i class="fas fa-info-circle"></i>
                </button>
                ${log.status === 'failed' ? `
                <button class="btn btn-outline btn-sm retry-log" data-id="${log.id}">
                    <i class="fas fa-redo"></i>
                </button>
                ` : ''}
            </td>
        `;

        tableBody.appendChild(row);
    });
}

// Update reminder statistics
function updateReminderStats() {
    const total = adminData.reminderLogs.length;
    const successful = adminData.reminderLogs.filter(log => log.status === 'sent').length;
    const failed = adminData.reminderLogs.filter(log => log.status === 'failed').length;
    const pending = adminData.reminderLogs.filter(log => log.status === 'pending').length;

    document.getElementById('totalReminders').textContent = total.toLocaleString();
    document.getElementById('successfulReminders').textContent = successful.toLocaleString();
    document.getElementById('failedReminders').textContent = failed.toLocaleString();
    document.getElementById('pendingReminders').textContent = pending.toLocaleString();
}

// Load upcoming events
async function loadUpcomingEvents() {
    try {
        // Mock data - replace with API call
        adminData.upcomingEvents = generateMockUpcomingEvents(30);

        renderUpcomingEvents();

    } catch (error) {
        console.error('Error loading upcoming events:', error);
        showNotification('Failed to load upcoming events', 'error');
    }
}

// Generate mock upcoming events
function generateMockUpcomingEvents(count) {
    const events = [];
    const eventTypes = ['Birthday', 'Wedding Anniversary', 'Child\'s Birthday'];

    for (let i = 0; i < count; i++) {
        const member = adminData.members[Math.floor(Math.random() * adminData.members.length)];
        const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
        const daysFromNow = Math.floor(Math.random() * 90); // Next 90 days

        events.push({
            id: `event_${i}`,
            memberId: member.id,
            memberName: member.fullName,
            memberEmail: member.email,
            eventType: eventType,
            eventDate: new Date(Date.now() + daysFromNow * 24 * 60 * 60 * 1000).toISOString(),
            reminderSent: Math.random() > 0.3,
            isAnnual: true
        });
    }

    // Sort by date (soonest first)
    return events.sort((a, b) => new Date(a.eventDate) - new Date(b.eventDate));
}

// Render upcoming events
function renderUpcomingEvents() {
    const eventsList = document.getElementById('upcomingEventsList');

    // Clear list
    eventsList.innerHTML = '';

    // Show only next 10 events
    const nextEvents = adminData.upcomingEvents.slice(0, 10);

    nextEvents.forEach(event => {
        const eventDate = new Date(event.eventDate);
        const today = new Date();
        const isToday = eventDate.toDateString() === today.toDateString();
        const daysUntil = Math.ceil((eventDate - today) / (1000 * 60 * 60 * 24));

        const eventCard = document.createElement('div');
        eventCard.className = `upcoming-event-card ${isToday ? 'today' : ''}`;

        eventCard.innerHTML = `
            <div>
                <h4 style="margin: 0 0 0.5rem;">${event.eventType}</h4>
                <p style="margin: 0; color: var(--text-light);">
                    <i class="fas fa-user"></i> ${event.memberName}
                </p>
                <p style="margin: 0.25rem 0 0; color: var(--text-light);">
                    <i class="fas fa-envelope"></i> ${event.memberEmail}
                </p>
            </div>
            <div style="text-align: right;">
                <div class="event-date-badge">
                    ${isToday ? 'TODAY' : `In ${daysUntil} days`}
                </div>
                <p style="margin: 0.5rem 0 0; color: var(--text-light); font-size: 0.9rem;">
                    ${formatDate(event.eventDate, 'full')}
                </p>
                <div style="margin-top: 0.5rem;">
                    <button class="btn btn-outline btn-sm send-reminder" data-id="${event.id}">
                        <i class="fas fa-bell"></i> Send Reminder
                    </button>
                </div>
            </div>
        `;

        eventsList.appendChild(eventCard);
    });
}

// Load system logs
async function loadSystemLogs() {
    try {
        // Mock data - replace with API call
        adminData.systemLogs = generateMockSystemLogs(50);

        renderSystemLogs();

    } catch (error) {
        console.error('Error loading system logs:', error);
        showNotification('Failed to load system logs', 'error');
    }
}

// Generate mock system logs
function generateMockSystemLogs(count) {
    const logs = [];
    const actions = ['LOGIN', 'REGISTER', 'UPDATE_PROFILE', 'ADD_DATE', 'DELETE_DATE', 'SEND_REMINDER'];
    const users = ['Admin', 'System', ...adminData.members.slice(0, 10).map(m => m.fullName)];

    for (let i = 0; i < count; i++) {
        const hoursAgo = Math.floor(Math.random() * 168); // Last week
        const user = users[Math.floor(Math.random() * users.length)];
        const action = actions[Math.floor(Math.random() * actions.length)];

        logs.push({
            id: `syslog_${i}`,
            timestamp: new Date(Date.now() - hoursAgo * 60 * 60 * 1000).toISOString(),
            userId: user.toLowerCase().replace(/\s+/g, '_'),
            userName: user,
            action: action,
            details: `${action.toLowerCase().replace(/_/g, ' ')} action performed`,
            ipAddress: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`
        });
    }

    // Sort by timestamp (newest first)
    return logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// Render system logs
function renderSystemLogs() {
    const tableBody = document.getElementById('logsTableBody');
    const searchTerm = document.getElementById('logSearch').value.toLowerCase();
    const typeFilter = document.getElementById('logTypeFilter').value;

    // Filter logs
    let filteredLogs = adminData.systemLogs.filter(log => {
        const matchesSearch =
            log.userName.toLowerCase().includes(searchTerm) ||
            log.action.toLowerCase().includes(searchTerm) ||
            log.details.toLowerCase().includes(searchTerm);

        const matchesType = !typeFilter || log.action === typeFilter.toUpperCase();

        return matchesSearch && matchesType;
    });

    // Clear table
    tableBody.innerHTML = '';

    if (filteredLogs.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state-cell">
                    <i class="fas fa-clipboard"></i>
                    <p>No logs found matching your criteria</p>
                </td>
            </tr>
        `;
        return;
    }

    // Add rows
    filteredLogs.forEach(log => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${formatDate(log.timestamp, 'full')}</td>
            <td>${log.userName}</td>
            <td>
                <span class="status-badge ${log.action === 'LOGIN' ? 'status-active' :
                log.action === 'REGISTER' ? 'status-pending' : 'status-inactive'
            }">
                    ${log.action.replace(/_/g, ' ')}
                </span>
            </td>
            <td>${log.details}</td>
            <td>${log.ipAddress}</td>
        `;

        tableBody.appendChild(row);
    });
}

// Generate calendar
function generateCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'];

    // Update month display
    document.getElementById('currentMonth').textContent =
        `${monthNames[adminData.currentMonth]} ${adminData.currentYear}`;

    // Get first day of month
    const firstDay = new Date(adminData.currentYear, adminData.currentMonth, 1);
    const lastDay = new Date(adminData.currentYear, adminData.currentMonth + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay(); // 0 = Sunday

    // Clear calendar
    calendarGrid.innerHTML = '';

    // Add day headers
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayNames.forEach(day => {
        const dayHeader = document.createElement('div');
        dayHeader.className = 'calendar-day-header';
        dayHeader.textContent = day;
        calendarGrid.appendChild(dayHeader);
    });

    // Add empty cells for days before first day of month
    for (let i = 0; i < startingDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'calendar-day';
        calendarGrid.appendChild(emptyDay);
    }

    // Add days of month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';

        const currentDate = new Date(adminData.currentYear, adminData.currentMonth, day);
        const dateStr = currentDate.toISOString().split('T')[0];

        // Find events for this day
        const dayEvents = adminData.upcomingEvents.filter(event => {
            const eventDate = new Date(event.eventDate).toISOString().split('T')[0];
            return eventDate === dateStr;
        });

        dayCell.innerHTML = `
            <div style="font-weight: 600; margin-bottom: 0.5rem;">${day}</div>
            ${dayEvents.slice(0, 2).map(event => `
                <div class="calendar-event" title="${event.eventType} - ${event.memberName}">
                    ${event.eventType.charAt(0)}: ${event.memberName.split(' ')[0]}
                </div>
            `).join('')}
            ${dayEvents.length > 2 ? `
                <div style="font-size: 0.8rem; color: var(--text-light); margin-top: 0.25rem;">
                    +${dayEvents.length - 2} more
                </div>
            ` : ''}
        `;

        // Highlight today
        const today = new Date();
        if (currentDate.toDateString() === today.toDateString()) {
            dayCell.style.backgroundColor = 'rgba(44, 90, 160, 0.05)';
            dayCell.style.border = '2px solid var(--primary-color)';
        }

        calendarGrid.appendChild(dayCell);
    }
}

// Show a specific section
function showSection(section) {
    // Hide all sections
    Object.values(sections).forEach(sec => {
        if (sec) {
            sec.style.display = 'none';
            sec.classList.remove('active-section');
        }
    });

    // Update navigation
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('data-section') === section) {
            item.classList.add('active');
        }
    });

    // Show selected section
    adminData.currentSection = section;
    const targetSection = sections[section];

    if (targetSection) {
        targetSection.style.display = 'block';
        targetSection.classList.add('active-section');

        // Update page title
        const sectionTitles = {
            'admin-dashboard': 'Admin Dashboard',
            'manage-members': 'Manage Members',
            'reminder-logs': 'Reminder Logs',
            'upcoming-events': 'Upcoming Events',
            'reports': 'Reports & Analytics',
            'system-logs': 'System Audit Logs',
            'settings': 'System Settings'
        };

        document.getElementById('pageTitle').textContent = sectionTitles[section] || 'Admin Dashboard';

        // Update subtitle
        const user = getCurrentUser();
        const subtitles = {
            'admin-dashboard': `Welcome ${user?.fullName?.split(' ')[0] || 'Admin'}, Welfare Secretary`,
            'manage-members': 'Manage PSN Taraba members',
            'reminder-logs': 'Track and manage reminder delivery',
            'upcoming-events': 'View upcoming celebrations',
            'reports': 'Generate reports and analytics',
            'system-logs': 'System audit trail and security logs',
            'settings': 'Configure system settings'
        };

        document.getElementById('pageSubtitle').textContent = subtitles[section] || 'Welfare Secretary Control Panel';
    }
}

// Update selected members count
function updateSelectedCount() {
    const count = adminData.selectedMembers.size;
    document.getElementById('selectedCount').textContent = count;

    // Enable/disable action buttons
    const exportBtn = document.getElementById('exportSelectedBtn');
    const deactivateBtn = document.getElementById('deactivateSelectedBtn');
    const deleteBtn = document.getElementById('deleteSelectedBtn');

    const hasSelection = count > 0;
    exportBtn.disabled = !hasSelection;
    deactivateBtn.disabled = !hasSelection;
    deleteBtn.disabled = !hasSelection;
}

// Update pagination
function updatePagination() {
    const totalPages = Math.ceil(adminData.totalMembers / adminData.itemsPerPage);
    const paginationInfo = document.querySelector('.pagination-info');
    const prevBtn = document.querySelector('.pagination-btn:first-child');
    const nextBtn = document.querySelector('.pagination-btn:last-child');

    paginationInfo.textContent = `Page ${adminData.currentPage} of ${totalPages}`;
    prevBtn.disabled = adminData.currentPage === 1;
    nextBtn.disabled = adminData.currentPage === totalPages;
}

// Setup event listeners
function setupAdminEventListeners() {
    // Mobile menu toggle
    document.getElementById('mobileMenuToggle').addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('open');
    });

    // Navigation
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            showSection(section);

            // Close mobile menu on selection
            if (window.innerWidth <= 992) {
                document.getElementById('sidebar').classList.remove('open');
            }
        });
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Refresh data button
    document.getElementById('refreshDataBtn').addEventListener('click', () => {
        showNotification('Refreshing data...', 'success');
        loadDashboardStats();
        loadMembers();
        loadReminderLogs();
        loadUpcomingEvents();
        loadSystemLogs();
    });

    // Quick export button
    document.getElementById('quickExportBtn').addEventListener('click', () => {
        showNotification('Preparing data export...', 'success');
        // Implement export functionality
        setTimeout(() => {
            showNotification('Export completed successfully', 'success');
        }, 1500);
    });

    // Quick action buttons
    document.getElementById('addMemberBtn').addEventListener('click', () => {
        showSection('manage-members');
        document.getElementById('addNewMemberBtn').click();
    });

    document.getElementById('sendAnnouncementBtn').addEventListener('click', () => {
        alert('Announcement feature will be implemented in the next version.');
    });

    document.getElementById('viewReportsBtn').addEventListener('click', () => {
        showSection('reports');
    });

    document.getElementById('systemHealthBtn').addEventListener('click', () => {
        showNotification('System health: All systems operational', 'success');
    });

    // Member search
    const searchInput = document.getElementById('memberSearch');
    const searchHandler = debounce(() => {
        adminData.currentPage = 1;
        renderMembersTable();
    }, 300);
    searchInput.addEventListener('input', searchHandler);

    // Member filters
    document.getElementById('statusFilter').addEventListener('change', () => {
        adminData.currentPage = 1;
        renderMembersTable();
    });

    document.getElementById('memberTypeFilter').addEventListener('change', () => {
        adminData.currentPage = 1;
        renderMembersTable();
    });

    document.getElementById('clearFiltersBtn').addEventListener('click', () => {
        document.getElementById('memberSearch').value = '';
        document.getElementById('statusFilter').value = '';
        document.getElementById('memberTypeFilter').value = '';
        adminData.currentPage = 1;
        renderMembersTable();
    });

    // Select all members checkbox
    document.getElementById('selectAllMembers').addEventListener('change', (e) => {
        const isChecked = e.target.checked;
        const checkboxes = document.querySelectorAll('.member-checkbox');

        if (isChecked) {
            checkboxes.forEach(cb => {
                const memberId = cb.getAttribute('data-id');
                adminData.selectedMembers.add(memberId);
                cb.checked = true;
            });
        } else {
            adminData.selectedMembers.clear();
            checkboxes.forEach(cb => cb.checked = false);
        }

        updateSelectedCount();
    });

    // Member table actions (delegated events)
    document.addEventListener('click', (e) => {
        // View member
        if (e.target.closest('.view-member')) {
            const memberId = e.target.closest('.view-member').getAttribute('data-id');
            viewMemberDetails(memberId);
        }

        // Edit member
        if (e.target.closest('.edit-member')) {
            const memberId = e.target.closest('.edit-member').getAttribute('data-id');
            editMember(memberId);
        }

        // Activate/Deactivate member
        if (e.target.closest('[data-action]')) {
            const button = e.target.closest('[data-action]');
            const memberId = button.getAttribute('data-id');
            const action = button.getAttribute('data-action');
            toggleMemberStatus(memberId, action);
        }

        // Member checkbox
        if (e.target.classList.contains('member-checkbox')) {
            const memberId = e.target.getAttribute('data-id');

            if (e.target.checked) {
                adminData.selectedMembers.add(memberId);
            } else {
                adminData.selectedMembers.delete(memberId);
                document.getElementById('selectAllMembers').checked = false;
            }

            updateSelectedCount();
        }
    });

    // Export selected members
    document.getElementById('exportSelectedBtn').addEventListener('click', () => {
        if (adminData.selectedMembers.size === 0) return;

        showNotification(`Exporting ${adminData.selectedMembers.size} members...`, 'success');
        // Implement export logic
    });

    // Deactivate selected members
    document.getElementById('deactivateSelectedBtn').addEventListener('click', () => {
        if (adminData.selectedMembers.size === 0) return;

        if (confirm(`Deactivate ${adminData.selectedMembers.size} selected members?`)) {
            adminData.selectedMembers.forEach(id => {
                const member = adminData.members.find(m => m.id === id);
                if (member) member.status = 'inactive';
            });
            renderMembersTable();
            showNotification('Members deactivated successfully', 'success');
        }
    });

    // Delete selected members
    document.getElementById('deleteSelectedBtn').addEventListener('click', () => {
        if (adminData.selectedMembers.size === 0) return;

        if (confirm(`Permanently delete ${adminData.selectedMembers.size} selected members? This action cannot be undone.`)) {
            adminData.members = adminData.members.filter(m => !adminData.selectedMembers.has(m.id));
            adminData.selectedMembers.clear();
            renderMembersTable();
            showNotification('Members deleted successfully', 'success');
        }
    });

    // Pagination
    document.querySelector('.pagination-btn:first-child').addEventListener('click', () => {
        if (adminData.currentPage > 1) {
            adminData.currentPage--;
            renderMembersTable();
            updatePagination();
        }
    });

    document.querySelector('.pagination-btn:last-child').addEventListener('click', () => {
        const totalPages = Math.ceil(adminData.totalMembers / adminData.itemsPerPage);
        if (adminData.currentPage < totalPages) {
            adminData.currentPage++;
            renderMembersTable();
            updatePagination();
        }
    });

    // Calendar navigation
    document.getElementById('prevMonth').addEventListener('click', () => {
        adminData.currentMonth--;
        if (adminData.currentMonth < 0) {
            adminData.currentMonth = 11;
            adminData.currentYear--;
        }
        generateCalendar();
    });

    document.getElementById('nextMonth').addEventListener('click', () => {
        adminData.currentMonth++;
        if (adminData.currentMonth > 11) {
            adminData.currentMonth = 0;
            adminData.currentYear++;
        }
        generateCalendar();
    });

    // Settings tabs
    document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');

            // Update active tab
            document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // Show corresponding content
            document.querySelectorAll('.settings-tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${tabId}-settings`).classList.add('active');
        });
    });

    // Add more event listeners as needed...
}

// View member details
function viewMemberDetails(memberId) {
    const member = adminData.members.find(m => m.id === memberId);
    if (!member) return;

    const modal = document.getElementById('viewMemberModal');
    const content = document.getElementById('memberDetailsContent');

    content.innerHTML = `
        <div class="member-details">
            <div class="detail-row">
                <div class="detail-label">PSN Number</div>
                <div class="detail-value">${member.psnNumber}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Full Name</div>
                <div class="detail-value">${member.fullName}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Email</div>
                <div class="detail-value">${member.email}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Phone</div>
                <div class="detail-value">${member.phone}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Status</div>
                <div class="detail-value">
                    <span class="status-badge ${member.status === 'active' ? 'status-active' : 'status-inactive'}">
                        ${member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                    </span>
                </div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Account Type</div>
                <div class="detail-value">${member.isAdmin ? 'Administrator' : 'Regular Member'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Registered Date</div>
                <div class="detail-value">${formatDate(member.registeredDate, 'full')}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Last Login</div>
                <div class="detail-value">${formatDate(member.lastLogin, 'full')}</div>
            </div>
        </div>
    `;

    modal.style.display = 'flex';

    // Close modal
    document.getElementById('closeMemberModal').addEventListener('click', () => {
        modal.style.display = 'none';
    });

    document.querySelector('#viewMemberModal .modal-close').addEventListener('click', () => {
        modal.style.display = 'none';
    });
}

// Edit member
function editMember(memberId) {
    const member = adminData.members.find(m => m.id === memberId);
    if (!member) return;

    showNotification(`Edit member: ${member.fullName}`, 'success');
    // Implement edit modal
}

// Toggle member status
function toggleMemberStatus(memberId, action) {
    const member = adminData.members.find(m => m.id === memberId);
    if (!member) return;

    const newStatus = action === 'deactivate' ? 'inactive' : 'active';
    const actionText = action === 'deactivate' ? 'deactivate' : 'activate';

    if (confirm(`${actionText.charAt(0).toUpperCase() + actionText.slice(1)} ${member.fullName}?`)) {
        member.status = newStatus;
        renderMembersTable();
        showNotification(`Member ${actionText}d successfully`, 'success');
    }
}

// Format date helper
function formatDate(dateString, format = 'short') {
    const date = new Date(dateString);

    if (format === 'short') {
        return date.toLocaleDateString();
    } else if (format === 'full') {
        return date.toLocaleString();
    }

    return date.toLocaleDateString();
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', initAdminDashboard);