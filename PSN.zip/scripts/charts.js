/**
 * Data Visualization with Charts.js for PSN Welfare Reports
 */

class ChartManager {
    constructor() {
        this.charts = new Map();
        this.colors = {
            primary: '#2c5aa0',
            secondary: '#34a853',
            accent: '#ff6b35',
            warning: '#f39c12',
            info: '#3498db',
            purple: '#9b59b6',
            teal: '#1abc9c'
        };

        // Initialize Charts.js
        this.initialize();
    }

    initialize() {
        // Load Charts.js if not already loaded
        if (typeof Chart === 'undefined') {
            this.loadChartJS();
        }

        // Add chart styles
        this.addStyles();
    }

    loadChartJS() {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';
        script.onload = () => {
            console.log('✅ Charts.js loaded');
            this.triggerChartsReady();
        };
        document.head.appendChild(script);
    }

    addStyles() {
        const styles = `
            <style>
                .chart-container {
                    position: relative;
                    height: 300px;
                    width: 100%;
                    margin: 20px 0;
                    background: white;
                    border-radius: 8px;
                    padding: 20px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                }
                
                .chart-title {
                    margin: 0 0 20px 0;
                    color: var(--primary-color);
                    font-size: 1.2rem;
                    font-weight: 600;
                }
                
                .chart-legend {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    margin-top: 20px;
                    font-size: 0.9rem;
                }
                
                .legend-item {
                    display: flex;
                    align-items: center;
                    gap: 5px;
                }
                
                .legend-color {
                    width: 15px;
                    height: 15px;
                    border-radius: 3px;
                }
                
                .chart-toolbar {
                    display: flex;
                    justify-content: flex-end;
                    gap: 10px;
                    margin-bottom: 10px;
                }
                
                .chart-period-selector {
                    display: flex;
                    gap: 5px;
                    margin-bottom: 20px;
                }
                
                .period-btn {
                    padding: 5px 15px;
                    border: 1px solid var(--border-color);
                    background: white;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 0.9rem;
                }
                
                .period-btn.active {
                    background: var(--primary-color);
                    color: white;
                    border-color: var(--primary-color);
                }
                
                .multi-chart-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                    gap: 20px;
                    margin: 20px 0;
                }
                
                @media (max-width: 768px) {
                    .multi-chart-grid {
                        grid-template-columns: 1fr;
                    }
                    
                    .chart-container {
                        height: 250px;
                    }
                }
            </style>
        `;

        document.head.insertAdjacentHTML('beforeend', styles);
    }

    // Create demographic chart
    createDemographicsChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Number of Members',
                    data: data.values,
                    backgroundColor: [
                        this.colors.primary,
                        this.colors.secondary,
                        this.colors.accent,
                        this.colors.info,
                        this.colors.purple
                    ],
                    borderColor: '#fff',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: { size: 14 },
                        bodyFont: { size: 14 },
                        padding: 12,
                        cornerRadius: 6
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            font: { size: 12 }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: { size: 12 }
                        }
                    }
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create age distribution chart
    createAgeDistributionChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                        '#9966FF', '#FF9F40', '#8AC926', '#1982C4'
                    ],
                    borderColor: '#fff',
                    borderWidth: 2,
                    hoverOffset: 15
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20,
                            font: { size: 12 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create monthly celebrations chart
    createMonthlyCelebrationsChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.months,
                datasets: [
                    {
                        label: 'Birthdays',
                        data: data.birthdays,
                        borderColor: this.colors.primary,
                        backgroundColor: this.transparentize(this.colors.primary, 0.1),
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Anniversaries',
                        data: data.anniversaries,
                        borderColor: this.colors.secondary,
                        backgroundColor: this.transparentize(this.colors.secondary, 0.1),
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: { size: 12 },
                            padding: 20
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Events'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create reminder performance chart
    createReminderPerformanceChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'polarArea',
            data: {
                labels: data.labels,
                datasets: [{
                    data: data.values,
                    backgroundColor: [
                        this.transparentize(this.colors.secondary, 0.7),
                        this.transparentize(this.colors.accent, 0.7),
                        this.transparentize(this.colors.warning, 0.7),
                        this.transparentize(this.colors.info, 0.7)
                    ],
                    borderColor: [
                        this.colors.secondary,
                        this.colors.accent,
                        this.colors.warning,
                        this.colors.info
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                },
                scales: {
                    r: {
                        ticks: {
                            display: false
                        }
                    }
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create member growth chart
    createMemberGrowthChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'New Members',
                        data: data.newMembers,
                        backgroundColor: this.transparentize(this.colors.primary, 0.7),
                        borderColor: this.colors.primary,
                        borderWidth: 1,
                        borderRadius: 6
                    },
                    {
                        label: 'Total Members',
                        data: data.totalMembers,
                        type: 'line',
                        borderColor: this.colors.secondary,
                        borderWidth: 3,
                        tension: 0.4,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Members'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Period'
                        }
                    }
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create real-time activity chart
    createActivityChart(containerId, data) {
        const ctx = document.getElementById(containerId);
        if (!ctx) return null;

        const chart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'This Week',
                        data: data.thisWeek,
                        borderColor: this.colors.primary,
                        backgroundColor: this.transparentize(this.colors.primary, 0.2),
                        borderWidth: 2
                    },
                    {
                        label: 'Last Week',
                        data: data.lastWeek,
                        borderColor: this.colors.secondary,
                        backgroundColor: this.transparentize(this.colors.secondary, 0.2),
                        borderWidth: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: {
                            display: true
                        },
                        suggestedMin: 0,
                        suggestedMax: Math.max(...data.thisWeek, ...data.lastWeek) * 1.2
                    }
                },
                plugins: {
                    legend: {
                        position: 'top'
                    }
                }
            }
        });

        this.charts.set(containerId, chart);
        return chart;
    }

    // Create dashboard summary charts
    createDashboardCharts(containerId, stats) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = '';

        // Create chart grid
        const grid = document.createElement('div');
        grid.className = 'multi-chart-grid';

        // 1. Member Growth Chart
        const growthChartContainer = this.createChartContainer('Member Growth Trend');
        const growthCanvas = document.createElement('canvas');
        growthCanvas.id = 'growthChart';
        growthChartContainer.appendChild(growthCanvas);
        grid.appendChild(growthChartContainer);

        // 2. Monthly Celebrations Chart
        const celebrationsContainer = this.createChartContainer('Monthly Celebrations');
        const celebrationsCanvas = document.createElement('canvas');
        celebrationsCanvas.id = 'celebrationsChart';
        celebrationsContainer.appendChild(celebrationsCanvas);
        grid.appendChild(celebrationsContainer);

        // 3. Reminder Performance Chart
        const reminderContainer = this.createChartContainer('Reminder Performance');
        const reminderCanvas = document.createElement('canvas');
        reminderCanvas.id = 'reminderChart';
        reminderContainer.appendChild(reminderCanvas);
        grid.appendChild(reminderContainer);

        // 4. Activity Distribution Chart
        const activityContainer = this.createChartContainer('Activity Distribution');
        const activityCanvas = document.createElement('canvas');
        activityCanvas.id = 'activityChart';
        activityContainer.appendChild(activityCanvas);
        grid.appendChild(activityContainer);

        container.appendChild(grid);

        // Initialize charts with sample data
        setTimeout(() => {
            this.createMemberGrowthChart('growthChart', {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                newMembers: [15, 22, 18, 25, 30, 28],
                totalMembers: [120, 142, 160, 185, 215, 243]
            });

            this.createMonthlyCelebrationsChart('celebrationsChart', {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                birthdays: [8, 12, 10, 15, 18, 14],
                anniversaries: [5, 7, 6, 9, 11, 8]
            });

            this.createReminderPerformanceChart('reminderChart', {
                labels: ['Sent', 'Delivered', 'Opened', 'Clicked'],
                values: [95, 92, 78, 45]
            });

            this.createActivityChart('activityChart', {
                labels: ['Logins', 'Profile Updates', 'Date Additions', 'Reminder Views', 'Admin Actions'],
                thisWeek: [65, 42, 38, 29, 15],
                lastWeek: [58, 35, 32, 25, 12]
            });
        }, 100);
    }

    createChartContainer(title) {
        const container = document.createElement('div');
        container.className = 'chart-container';

        const titleElement = document.createElement('h3');
        titleElement.className = 'chart-title';
        titleElement.textContent = title;

        container.appendChild(titleElement);
        return container;
    }

    // Export chart as image
    exportChart(chartId, format = 'png', quality = 1.0) {
        const chart = this.charts.get(chartId);
        if (!chart) return null;

        const canvas = chart.canvas;
        const link = document.createElement('a');
        link.download = `chart-${chartId}-${new Date().toISOString().split('T')[0]}.${format}`;
        link.href = canvas.toDataURL(`image/${format}`, quality);
        link.click();

        return link.href;
    }

    // Export all charts as PDF
    exportAllCharts() {
        const charts = Array.from(this.charts.values());
        if (charts.length === 0) return;

        // In production, use a PDF generation library
        // For now, create a zip of images
        charts.forEach((chart, index) => {
            setTimeout(() => {
                this.exportChart(chart.canvas.id, 'png');
            }, index * 500);
        });
    }

    // Update chart data
    updateChart(chartId, newData) {
        const chart = this.charts.get(chartId);
        if (!chart) return;

        chart.data = newData;
        chart.update();
    }

    // Destroy chart
    destroyChart(chartId) {
        const chart = this.charts.get(chartId);
        if (chart) {
            chart.destroy();
            this.charts.delete(chartId);
        }
    }

    // Destroy all charts
    destroyAllCharts() {
        this.charts.forEach((chart, chartId) => {
            chart.destroy();
        });
        this.charts.clear();
    }

    // Helper: Create transparent color
    transparentize(color, alpha) {
        const hex = color.replace('#', '');
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    // Helper: Trigger charts ready event
    triggerChartsReady() {
        const event = new CustomEvent('chartsReady');
        document.dispatchEvent(event);
    }

    // Get sample data for testing
    getSampleData() {
        return {
            demographics: {
                labels: ['Under 30', '30-40', '40-50', '50-60', '60+'],
                values: [25, 42, 58, 27, 8]
            },
            monthlyCelebrations: {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                birthdays: [12, 15, 18, 14, 22, 19, 16, 21, 20, 18, 17, 14],
                anniversaries: [8, 7, 9, 6, 11, 10, 8, 12, 9, 10, 8, 7]
            }
        };
    }
}

// Create global chart manager instance
const chartManager = new ChartManager();

// Initialize charts when Charts.js is loaded
if (typeof Chart !== 'undefined') {
    chartManager.triggerChartsReady();
} else {
    document.addEventListener('chartsReady', () => {
        console.log('Charts.js ready, initializing charts...');
    });
}

// Export for use in other modules
window.chartManager = chartManager;