/**
 * Backup System for PSN Welfare Registry
 */

class BackupManager {
    constructor() {
        this.backups = [];
        this.autoBackupInterval = null;
        this.backupSettings = {
            autoBackup: true,
            frequency: 'daily', // daily, weekly, monthly
            retentionDays: 30,
            backupLocation: 'server' // server, cloud, both
        };
    }

    // Initialize backup system
    async initialize() {
        await this.loadBackupSettings();
        await this.loadBackups();
        this.setupAutoBackup();
        this.setupBackupUI();
    }

    // Load backup settings
    async loadBackupSettings() {
        try {
            const response = await ApiService.getSystemSettings();
            this.backupSettings = response.backupSettings || this.backupSettings;
        } catch (error) {
            console.error('Failed to load backup settings:', error);
        }
    }

    // Load existing backups
    async loadBackups() {
        try {
            const response = await ApiService.getBackups();
            this.backups = response.data || [];
            this.renderBackupList();
        } catch (error) {
            console.error('Failed to load backups:', error);
        }
    }

    // Create new backup
    async createBackup(manual = false) {
        try {
            showNotification('Creating backup...', 'info');

            const response = await ApiService.createBackup();

            if (response.success) {
                showNotification('Backup created successfully', 'success');

                // Reload backups list
                await this.loadBackups();

                // Log backup creation
                if (manual) {
                    await AuditLogger.logAction('BACKUP_CREATED', {
                        backupId: response.backupId,
                        size: response.size,
                        manual: true
                    });
                }

                return response;
            }
        } catch (error) {
            console.error('Backup creation error:', error);
            showNotification(`Backup failed: ${error.message}`, 'error');
            throw error;
        }
    }

    // Restore from backup
    async restoreBackup(backupId) {
        if (!confirm('Are you sure you want to restore this backup? This will overwrite current data.')) {
            return;
        }

        try {
            showNotification('Restoring backup...', 'info');

            const response = await ApiService.restoreBackup(backupId);

            if (response.success) {
                showNotification('Backup restored successfully', 'success');

                // Log restoration
                await AuditLogger.logAction('BACKUP_RESTORED', {
                    backupId: backupId,
                    timestamp: new Date().toISOString()
                });

                // Reload page after restore
                setTimeout(() => {
                    window.location.reload();
                }, 2000);

                return response;
            }
        } catch (error) {
            console.error('Backup restoration error:', error);
            showNotification(`Restore failed: ${error.message}`, 'error');
            throw error;
        }
    }

    // Delete backup
    async deleteBackup(backupId) {
        if (!confirm('Are you sure you want to delete this backup?')) {
            return;
        }

        try {
            showNotification('Deleting backup...', 'info');

            const response = await fetch(`${API_BASE_URL}/admin/backup/${backupId}`, {
                method: 'DELETE',
                headers: getAuthHeaders()
            });

            if (response.ok) {
                showNotification('Backup deleted successfully', 'success');

                // Remove from local list
                this.backups = this.backups.filter(b => b.id !== backupId);
                this.renderBackupList();

                // Log deletion
                await AuditLogger.logAction('BACKUP_DELETED', {
                    backupId: backupId
                });
            }
        } catch (error) {
            console.error('Backup deletion error:', error);
            showNotification(`Delete failed: ${error.message}`, 'error');
        }
    }

    // Export backup
    async exportBackup(backupId, format = 'zip') {
        try {
            showNotification('Exporting backup...', 'info');

            const response = await fetch(`${API_BASE_URL}/admin/backup/${backupId}/export?format=${format}`, {
                headers: getAuthHeaders()
            });

            if (!response.ok) throw new Error('Export failed');

            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `psn_backup_${backupId}_${new Date().toISOString().split('T')[0]}.${format}`;
            document.body.appendChild(a);
            a.click();
            URL.revokeObjectURL(url);
            document.body.removeChild(a);

            showNotification('Backup exported successfully', 'success');

            // Log export
            await AuditLogger.logAction('BACKUP_EXPORTED', {
                backupId: backupId,
                format: format
            });

        } catch (error) {
            console.error('Backup export error:', error);
            showNotification(`Export failed: ${error.message}`, 'error');
        }
    }

    // Setup auto-backup schedule
    setupAutoBackup() {
        if (!this.backupSettings.autoBackup) return;

        // Clear existing interval
        if (this.autoBackupInterval) {
            clearInterval(this.autoBackupInterval);
        }

        // Calculate interval based on frequency
        let interval;
        switch (this.backupSettings.frequency) {
            case 'daily':
                interval = 24 * 60 * 60 * 1000; // 24 hours
                break;
            case 'weekly':
                interval = 7 * 24 * 60 * 60 * 1000; // 7 days
                break;
            case 'monthly':
                interval = 30 * 24 * 60 * 60 * 1000; // 30 days
                break;
            default:
                interval = 24 * 60 * 60 * 1000;
        }

        // Schedule auto-backup
        this.autoBackupInterval = setInterval(async () => {
            await this.createBackup(false);
        }, interval);

        console.log(`Auto-backup scheduled: ${this.backupSettings.frequency}`);
    }

    // Setup backup UI
    setupBackupUI() {
        // Update last backup display
        if (this.backups.length > 0) {
            const latestBackup = this.backups[0];
            const lastBackupElement = document.getElementById('lastBackup');
            if (lastBackupElement) {
                lastBackupElement.textContent = new Date(latestBackup.createdAt).toLocaleString();
            }
        }

        // Setup event listeners
        this.setupEventListeners();
    }

    // Render backup list
    renderBackupList() {
        const container = document.getElementById('backupList');
        if (!container) return;

        container.innerHTML = '';

        if (this.backups.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-database"></i>
                    <h3>No backups found</h3>
                    <p>Create your first backup to protect your data</p>
                </div>
            `;
            return;
        }

        this.backups.forEach(backup => {
            const backupCard = document.createElement('div');
            backupCard.className = 'backup-card';
            backupCard.innerHTML = `
                <div class="backup-header">
                    <h4>Backup ${new Date(backup.createdAt).toLocaleDateString()}</h4>
                    <span class="backup-size">${this.formatSize(backup.size)}</span>
                </div>
                <div class="backup-details">
                    <div class="detail-item">
                        <i class="fas fa-calendar"></i>
                        <span>${new Date(backup.createdAt).toLocaleString()}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-hdd"></i>
                        <span>${backup.type === 'full' ? 'Full Backup' : 'Incremental'}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-check-circle" style="color: ${backup.status === 'completed' ? '#28a745' : '#dc3545'}"></i>
                        <span>${backup.status}</span>
                    </div>
                </div>
                <div class="backup-actions">
                    <button class="btn btn-outline btn-sm restore-backup" data-id="${backup.id}">
                        <i class="fas fa-undo"></i> Restore
                    </button>
                    <button class="btn btn-outline btn-sm export-backup" data-id="${backup.id}">
                        <i class="fas fa-download"></i> Export
                    </button>
                    <button class="btn btn-outline btn-sm btn-danger delete-backup" data-id="${backup.id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            `;

            container.appendChild(backupCard);
        });
    }

    // Setup event listeners
    setupEventListeners() {
        // Backup now button
        const backupNowBtn = document.getElementById('backupNowBtn');
        if (backupNowBtn) {
            backupNowBtn.addEventListener('click', () => this.createBackup(true));
        }

        // Restore backup button
        const restoreBackupBtn = document.getElementById('restoreBackupBtn');
        if (restoreBackupBtn) {
            restoreBackupBtn.addEventListener('click', () => {
                if (this.backups.length > 0) {
                    this.restoreBackup(this.backups[0].id);
                }
            });
        }

        // Export all data button
        const exportAllDataBtn = document.getElementById('exportAllDataBtn');
        if (exportAllDataBtn) {
            exportAllDataBtn.addEventListener('click', () => this.exportAllData());
        }

        // Backup frequency selector
        const backupFrequency = document.getElementById('backupFrequency');
        if (backupFrequency) {
            backupFrequency.value = this.backupSettings.frequency;
            backupFrequency.addEventListener('change', (e) => {
                this.backupSettings.frequency = e.target.value;
                this.saveBackupSettings();
                this.setupAutoBackup();
            });
        }

        // Delegated events for backup cards
        document.addEventListener('click', (e) => {
            if (e.target.closest('.restore-backup')) {
                const backupId = e.target.closest('.restore-backup').dataset.id;
                this.restoreBackup(backupId);
            }

            if (e.target.closest('.export-backup')) {
                const backupId = e.target.closest('.export-backup').dataset.id;
                this.exportBackup(backupId);
            }

            if (e.target.closest('.delete-backup')) {
                const backupId = e.target.closest('.delete-backup').dataset.id;
                this.deleteBackup(backupId);
            }
        });
    }

    // Export all data
    async exportAllData() {
        try {
            showNotification('Exporting all data...', 'info');
            await ApiService.exportData('json');

            // Log export
            await AuditLogger.logAction('FULL_DATA_EXPORT', {
                timestamp: new Date().toISOString(),
                format: 'json'
            });

        } catch (error) {
            console.error('Full export error:', error);
            showNotification(`Export failed: ${error.message}`, 'error');
        }
    }

    // Save backup settings
    async saveBackupSettings() {
        try {
            await ApiService.updateSystemSettings({
                backupSettings: this.backupSettings
            });
            showNotification('Backup settings saved', 'success');
        } catch (error) {
            console.error('Save settings error:', error);
            showNotification('Failed to save settings', 'error');
        }
    }

    // Helper: Format file size
    formatSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Helper: Get backup status
    getBackupStatus(backup) {
        const now = new Date();
        const backupDate = new Date(backup.createdAt);
        const diffDays = Math.floor((now - backupDate) / (1000 * 60 * 60 * 24));

        if (diffDays <= 1) return 'fresh';
        if (diffDays <= 7) return 'recent';
        if (diffDays <= 30) return 'old';
        return 'outdated';
    }
}

// Initialize backup manager
const BackupSystem = new BackupManager();

// Auto-initialize on admin pages
if (window.location.pathname.includes('admin.html')) {
    document.addEventListener('DOMContentLoaded', () => {
        BackupSystem.initialize();
    });
}