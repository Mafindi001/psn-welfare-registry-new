/**
 * Bulk Actions Module for PSN Welfare Registry
 */

class BulkActionsManager {
    constructor() {
        this.selectedMembers = new Set();
        this.emailTemplates = {
            welcome: {
                subject: 'Welcome to PSN Taraba Welfare Registry',
                body: `Dear {name},

Welcome to the Pharmaceutical Society of Nigeria, Taraba State Chapter Welfare Registry.

Your account has been created successfully:
- PSN Number: {psnNumber}
- Login Email: {email}

Please login to update your profile and add special dates for automated reminders.

Best regards,
PSN Taraba Welfare Team`
            },
            announcement: {
                subject: 'Important Announcement from PSN Taraba',
                body: `Dear {name},

{announcement}

Best regards,
PSN Taraba Executive Council`
            },
            reminder: {
                subject: 'Reminder: Update Your Profile',
                body: `Dear {name},

This is a reminder to update your profile information in the PSN Welfare Registry.

Please ensure your contact details and next-of-kin information are up to date.

Best regards,
PSN Taraba Welfare Team`
            }
        };
    }

    // Send bulk emails
    async sendBulkEmails(templateType, customData = {}) {
        if (this.selectedMembers.size === 0) {
            showNotification('Please select members first', 'error');
            return;
        }

        const template = this.emailTemplates[templateType] || this.emailTemplates.announcement;

        try {
            showNotification(`Preparing emails for ${this.selectedMembers.size} members...`, 'info');

            const memberIds = Array.from(this.selectedMembers);
            const members = await this.getMemberDetails(memberIds);

            const emailData = {
                templateType,
                subject: customData.subject || template.subject,
                body: customData.body || template.body,
                members: members.map(member => ({
                    id: member.id,
                    email: member.email,
                    variables: {
                        name: member.fullName,
                        psnNumber: member.psnNumber,
                        ...customData.variables
                    }
                })),
                sendCopyToAdmin: customData.sendCopyToAdmin || false
            };

            const response = await ApiService.sendBulkEmails(emailData);

            showNotification(`Emails sent successfully to ${response.sentCount} members`, 'success');

            // Log bulk action
            await this.logBulkAction('BULK_EMAIL', {
                count: response.sentCount,
                templateType,
                memberCount: this.selectedMembers.size
            });

            return response;

        } catch (error) {
            console.error('Bulk email error:', error);
            showNotification(`Failed to send emails: ${error.message}`, 'error');
            throw error;
        }
    }

    // Send bulk reminders
    async sendBulkReminders(reminderType, customMessage = null) {
        if (this.selectedMembers.size === 0) {
            showNotification('Please select members first', 'error');
            return;
        }

        try {
            showNotification(`Sending reminders to ${this.selectedMembers.size} members...`, 'info');

            const memberIds = Array.from(this.selectedMembers);

            const reminderData = {
                memberIds,
                reminderType,
                message: customMessage,
                sendToNextOfKin: true,
                scheduleDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // Tomorrow
            };

            const response = await ApiService.sendBulkReminders(reminderData);

            showNotification(`Reminders scheduled for ${response.scheduledCount} members`, 'success');

            // Log bulk action
            await this.logBulkAction('BULK_REMINDER', {
                count: response.scheduledCount,
                reminderType,
                memberCount: this.selectedMembers.size
            });

            return response;

        } catch (error) {
            console.error('Bulk reminder error:', error);
            showNotification(`Failed to schedule reminders: ${error.message}`, 'error');
            throw error;
        }
    }

    // Update member status in bulk
    async updateMemberStatusBulk(status) {
        if (this.selectedMembers.size === 0) {
            showNotification('Please select members first', 'error');
            return;
        }

        const action = status === 'active' ? 'activate' : 'deactivate';

        if (!confirm(`Are you sure you want to ${action} ${this.selectedMembers.size} members?`)) {
            return;
        }

        try {
            showNotification(`${action.charAt(0).toUpperCase() + action.slice(1)}ing ${this.selectedMembers.size} members...`, 'info');

            const memberIds = Array.from(this.selectedMembers);
            const updates = memberIds.map(id => ({
                id,
                status
            }));

            // Call API for each member (or implement bulk endpoint)
            const promises = updates.map(update =>
                ApiService.updateMember(update.id, { status: update.status })
            );

            await Promise.all(promises);

            showNotification(`${this.selectedMembers.size} members ${action}d successfully`, 'success');

            // Log bulk action
            await this.logBulkAction('BULK_STATUS_UPDATE', {
                action,
                count: this.selectedMembers.size,
                newStatus: status
            });

            // Clear selection
            this.selectedMembers.clear();
            this.updateSelectionUI();

            // Refresh members table
            if (typeof renderMembersTable === 'function') {
                renderMembersTable();
            }

        } catch (error) {
            console.error('Bulk status update error:', error);
            showNotification(`Failed to update member status: ${error.message}`, 'error');
        }
    }

    // Export selected members data
    async exportSelectedMembers(format = 'csv') {
        if (this.selectedMembers.size === 0) {
            showNotification('Please select members first', 'error');
            return;
        }

        try {
            showNotification(`Exporting ${this.selectedMembers.size} members as ${format.toUpperCase()}...`, 'info');

            const memberIds = Array.from(this.selectedMembers);
            const members = await this.getMemberDetails(memberIds);

            let content;
            let filename = `psn_members_export_${new Date().toISOString().split('T')[0]}`;

            switch (format) {
                case 'csv':
                    content = this.convertToCSV(members);
                    filename += '.csv';
                    break;
                case 'excel':
                    content = this.convertToExcel(members);
                    filename += '.xlsx';
                    break;
                case 'json':
                    content = JSON.stringify(members, null, 2);
                    filename += '.json';
                    break;
                default:
                    throw new Error('Unsupported format');
            }

            this.downloadFile(content, filename, format);

            showNotification('Export completed successfully', 'success');

            // Log export
            await this.logBulkAction('BULK_EXPORT', {
                format,
                count: members.length
            });

        } catch (error) {
            console.error('Export error:', error);
            showNotification(`Export failed: ${error.message}`, 'error');
        }
    }

    // Helper: Convert members to CSV
    convertToCSV(members) {
        const headers = ['PSN Number', 'Full Name', 'Email', 'Phone', 'Status', 'Type', 'Registered Date', 'Last Login'];

        const rows = members.map(member => [
            `"${member.psnNumber}"`,
            `"${member.fullName}"`,
            `"${member.email}"`,
            `"${member.phone}"`,
            `"${member.status}"`,
            `"${member.isAdmin ? 'Admin' : 'Member'}"`,
            `"${new Date(member.registeredDate).toLocaleDateString()}"`,
            `"${new Date(member.lastLogin).toLocaleDateString()}"`
        ]);

        return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    }

    // Helper: Convert members to Excel (simplified)
    convertToExcel(members) {
        // In production, use a library like SheetJS
        // This is a simplified version
        const csv = this.convertToCSV(members);
        return csv; // For demo, return CSV
    }

    // Helper: Download file
    downloadFile(content, filename, type) {
        const blob = new Blob([content], { type: this.getMimeType(type) });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    // Helper: Get MIME type
    getMimeType(format) {
        const types = {
            'csv': 'text/csv',
            'excel': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'json': 'application/json',
            'pdf': 'application/pdf'
        };
        return types[format] || 'text/plain';
    }

    // Helper: Get member details
    async getMemberDetails(memberIds) {
        // Mock implementation - replace with actual API
        return Promise.all(
            memberIds.map(id => ApiService.getMemberDetails(id))
        );
    }

    // Update selection UI
    updateSelectionUI() {
        const count = this.selectedMembers.size;
        const countElement = document.getElementById('selectedCount');
        if (countElement) {
            countElement.textContent = count;
        }

        // Enable/disable bulk action buttons
        const bulkButtons = ['exportSelectedBtn', 'deactivateSelectedBtn', 'deleteSelectedBtn', 'sendBulkEmailBtn', 'sendBulkReminderBtn'];
        bulkButtons.forEach(btnId => {
            const btn = document.getElementById(btnId);
            if (btn) {
                btn.disabled = count === 0;
            }
        });
    }

    // Log bulk action
    async logBulkAction(action, details = {}) {
        try {
            await fetch(`${API_BASE_URL}/admin/audit-logs`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify({
                    action,
                    details: {
                        ...details,
                        performedBy: getCurrentUser()?.id,
                        timestamp: new Date().toISOString()
                    },
                    type: 'BULK_ACTION'
                })
            });
        } catch (error) {
            console.error('Audit log error:', error);
        }
    }
}

// Initialize bulk actions manager
const BulkManager = new BulkActionsManager();